import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface User {
  username: string;
  email: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => { success: boolean; error?: string };
  register: (username: string, email: string, password: string) => { success: boolean; error?: string };
  logout: () => void;
  showAuthModal: boolean;
  setShowAuthModal: (v: boolean) => void;
  authTab: "login" | "register";
  setAuthTab: (v: "login" | "register") => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authTab, setAuthTab] = useState<"login" | "register">("login");

  useEffect(() => {
    const stored = localStorage.getItem("rt_user");
    if (stored) {
      try { setUser(JSON.parse(stored)); } catch {}
    }
  }, []);

  function getUsers(): Record<string, { password: string; email: string; createdAt: string }> {
    try { return JSON.parse(localStorage.getItem("rt_users") || "{}"); } catch { return {}; }
  }

  function saveUsers(users: Record<string, { password: string; email: string; createdAt: string }>) {
    localStorage.setItem("rt_users", JSON.stringify(users));
  }

  function login(username: string, password: string) {
    const users = getUsers();
    const entry = users[username.toLowerCase()];
    if (!entry) return { success: false, error: "Kullanıcı bulunamadı." };
    if (entry.password !== password) return { success: false, error: "Şifre yanlış." };
    const u: User = { username, email: entry.email, createdAt: entry.createdAt };
    setUser(u);
    localStorage.setItem("rt_user", JSON.stringify(u));
    return { success: true };
  }

  function register(username: string, email: string, password: string) {
    if (!username.trim() || !email.trim() || !password.trim())
      return { success: false, error: "Tüm alanları doldurun." };
    if (username.length < 3)
      return { success: false, error: "Kullanıcı adı en az 3 karakter olmalı." };
    if (password.length < 6)
      return { success: false, error: "Şifre en az 6 karakter olmalı." };
    const users = getUsers();
    if (users[username.toLowerCase()])
      return { success: false, error: "Bu kullanıcı adı zaten alınmış." };
    const createdAt = new Date().toISOString();
    users[username.toLowerCase()] = { password, email, createdAt };
    saveUsers(users);
    const u: User = { username, email, createdAt };
    setUser(u);
    localStorage.setItem("rt_user", JSON.stringify(u));
    return { success: true };
  }

  function logout() {
    setUser(null);
    localStorage.removeItem("rt_user");
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout, showAuthModal, setShowAuthModal, authTab, setAuthTab }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
