import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ShieldAlert, Eye, EyeOff, User, Mail, Lock, LogIn, UserPlus } from "lucide-react";
import { useAuth } from "@/context/auth-context";

export function AuthModal() {
  const { showAuthModal, setShowAuthModal, authTab, setAuthTab, login, register } = useAuth();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function close() {
    setShowAuthModal(false);
    setError("");
    setUsername("");
    setEmail("");
    setPassword("");
  }

  function switchTab(tab: "login" | "register") {
    setAuthTab(tab);
    setError("");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    await new Promise(r => setTimeout(r, 400));
    if (authTab === "login") {
      const res = login(username, password);
      if (!res.success) setError(res.error || "Hata oluştu.");
      else close();
    } else {
      const res = register(username, email, password);
      if (!res.success) setError(res.error || "Hata oluştu.");
      else close();
    }
    setLoading(false);
  }

  return (
    <AnimatePresence>
      {showAuthModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
          onClick={(e) => { if (e.target === e.currentTarget) close(); }}
        >
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />

          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: "spring", duration: 0.4 }}
            className="relative w-full max-w-md bg-[#0d0d0d] border border-white/10 rounded-2xl overflow-hidden shadow-[0_0_80px_rgba(220,38,38,0.2)]"
          >
            {/* Top accent */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent" />

            {/* Header */}
            <div className="flex items-center justify-between px-8 pt-8 pb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <ShieldAlert className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h2 className="font-display font-bold text-lg text-foreground">
                    {authTab === "login" ? "Giriş Yap" : "Kayıt Ol"}
                  </h2>
                  <p className="text-xs text-muted-foreground">Aethron System</p>
                </div>
              </div>
              <button
                onClick={close}
                className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tabs */}
            <div className="flex mx-8 mb-6 bg-white/5 rounded-xl p-1 gap-1">
              {(["login", "register"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => switchTab(tab)}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-display font-bold uppercase tracking-wider transition-all duration-200 ${
                    authTab === tab
                      ? "bg-primary text-primary-foreground shadow-[0_0_15px_rgba(220,38,38,0.4)]"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {tab === "login" ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                  {tab === "login" ? "Giriş" : "Kayıt"}
                </button>
              ))}
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="px-8 pb-8 space-y-4">
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Kullanıcı Adı"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pl-11 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 focus:bg-white/8 transition-all"
                />
              </div>

              <AnimatePresence>
                {authTab === "register" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="relative overflow-hidden"
                  >
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <input
                      type="email"
                      placeholder="E-posta Adresi"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required={authTab === "register"}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pl-11 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 focus:bg-white/8 transition-all"
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Şifre"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pl-11 pr-11 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/60 focus:bg-white/8 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              <AnimatePresence>
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    className="text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-3"
                  >
                    {error}
                  </motion.div>
                )}
              </AnimatePresence>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl font-display font-bold uppercase tracking-wider text-sm bg-primary text-primary-foreground hover:shadow-[0_0_25px_rgba(220,38,38,0.5)] disabled:opacity-60 transition-all duration-300 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : authTab === "login" ? (
                  <><LogIn className="w-4 h-4" /> Giriş Yap</>
                ) : (
                  <><UserPlus className="w-4 h-4" /> Kayıt Ol</>
                )}
              </button>

              <p className="text-center text-xs text-muted-foreground">
                {authTab === "login" ? "Hesabın yok mu? " : "Zaten hesabın var mı? "}
                <button
                  type="button"
                  onClick={() => switchTab(authTab === "login" ? "register" : "login")}
                  className="text-primary hover:underline font-semibold"
                >
                  {authTab === "login" ? "Kayıt Ol" : "Giriş Yap"}
                </button>
              </p>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
