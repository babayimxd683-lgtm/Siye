import { useState } from "react";
import { motion } from "framer-motion";
import {
  Database,
  Network,
  ShieldAlert,
  KeyRound,
  Globe,
  GraduationCap,
  Wifi,
  Terminal,
  Fingerprint,
  Bug,
  ArrowRight,
  Lock as LockIcon,
} from "lucide-react";
import { useAuth } from "@/context/auth-context";
import { ToolModal } from "@/components/tools/tool-modal";

const categories = [
  {
    category: "Bilgi Toplama",
    subtitle: "Information Gathering",
    color: "from-blue-600/20 to-blue-400/10",
    borderColor: "border-blue-500/30",
    iconColor: "text-blue-400",
    bgColor: "bg-blue-500/10",
    icon: Database,
    tools: [
      { name: "WHOIS Sorgulama", desc: "Domain ve IP adresi hakkında kayıt bilgilerini sorgula" },
      { name: "DNS Keşif", desc: "DNS kayıtlarını, alt alanları ve zone transfer zafiyetlerini tara" },
      { name: "IP Geolocation", desc: "IP adresinin coğrafi konumunu ve ISP bilgisini tespit et" },
      { name: "E-posta Toplama", desc: "Hedef alan adına ait e-posta adreslerini açık kaynaklardan topla" },
      { name: "OSINT Araçları", desc: "Sosyal medya ve açık kaynaklardan hedef hakkında veri topla" },
      { name: "Subdomain Tarayıcı", desc: "Alt alan adlarını brute-force ve pasif yöntemlerle keşfet" },
    ],
  },
  {
    category: "Ağ Taraması",
    subtitle: "Network Scanning",
    color: "from-primary/20 to-orange-500/10",
    borderColor: "border-primary/30",
    iconColor: "text-primary",
    bgColor: "bg-primary/10",
    icon: Network,
    tools: [
      { name: "Port Tarayıcı", desc: "Hedef sistemdeki açık TCP/UDP portlarını hızlıca tara" },
      { name: "Servis Tespiti", desc: "Açık portlarda çalışan servis ve sürüm bilgilerini tespit et" },
      { name: "Ping Taraması", desc: "Ağdaki aktif cihazları ICMP ile hızlıca keşfet" },
      { name: "Traceroute", desc: "Hedef sisteme giden ağ yolunu ve hop noktalarını izle" },
      { name: "ARP Taraması", desc: "Yerel ağdaki tüm cihazları ARP protokolü ile tara" },
      { name: "Banner Grabbing", desc: "Servis banner bilgilerini toplayarak sistem parmak izi çıkar" },
    ],
  },
  {
    category: "Güvenlik Açığı Analizi",
    subtitle: "Vulnerability Assessment",
    color: "from-red-600/20 to-red-400/10",
    borderColor: "border-red-500/30",
    iconColor: "text-red-400",
    bgColor: "bg-red-500/10",
    icon: Bug,
    tools: [
      { name: "CVE Tarayıcı", desc: "Hedef sistemdeki bilinen CVE açıklarını otomatik olarak tara" },
      { name: "SQL Injection Test", desc: "Web uygulamalarındaki SQL enjeksiyon açıklarını tespit et" },
      { name: "XSS Tespiti", desc: "Cross-Site Scripting zafiyetlerini tespit et ve raporla" },
      { name: "SSL/TLS Analizi", desc: "SSL/TLS yapılandırma hatalarını ve zayıf şifreleri analiz et" },
      { name: "Misconfiguration Tarayıcı", desc: "Yanlış yapılandırılmış servis ve güvenlik ayarlarını bul" },
      { name: "Exploit Veritabanı", desc: "Bilinen exploit'leri ara, filtrele ve hızlıca erişim sağla" },
    ],
  },
  {
    category: "Şifre Araçları",
    subtitle: "Password Tools",
    color: "from-purple-600/20 to-purple-400/10",
    borderColor: "border-purple-500/30",
    iconColor: "text-purple-400",
    bgColor: "bg-purple-500/10",
    icon: KeyRound,
    tools: [
      { name: "Hash Kırıcı", desc: "MD5, SHA1, SHA256 ve diğer hash türlerini kırmaya çalış" },
      { name: "Wordlist Üretici", desc: "Özelleştirilmiş parola listesi oluştur ve düzenle" },
      { name: "Brute Force", desc: "Servisler üzerinde brute-force saldırı testi gerçekleştir" },
      { name: "Şifre Gücü Testi", desc: "Parolanın tahmin edilme süresini ve güvenlik skorunu ölç" },
      { name: "Hash Tanımlayıcı", desc: "Hash türünü otomatik olarak tespit et ve kategorize et" },
      { name: "Credential Dump Analiz", desc: "Sızdırılmış kimlik bilgisi listelerini analiz et" },
    ],
  },
  {
    category: "Web Analizi",
    subtitle: "Web Analysis",
    color: "from-green-600/20 to-green-400/10",
    borderColor: "border-green-500/30",
    iconColor: "text-green-400",
    bgColor: "bg-green-500/10",
    icon: Globe,
    tools: [
      { name: "Dizin Tarayıcı", desc: "Gizli dizin ve dosyaları brute-force yöntemiyle keşfet" },
      { name: "HTTP Başlık Analizi", desc: "HTTP başlıklarını güvenlik açısından incele ve raporla" },
      { name: "CMS Tespiti", desc: "WordPress, Joomla gibi CMS sistemlerini otomatik tespit et" },
      { name: "Web Crawler", desc: "Web sitesindeki tüm linkleri, formu ve kaynakları tara" },
      { name: "Cookie Analizi", desc: "Oturum çerezlerini güvenlik açısından analiz et" },
      { name: "API Keşif", desc: "Açıkta kalan API endpoint'leri ve parametreleri bul" },
    ],
  },
  {
    category: "Kablosuz Ağ",
    subtitle: "Wireless Security",
    color: "from-yellow-600/20 to-yellow-400/10",
    borderColor: "border-yellow-500/30",
    iconColor: "text-yellow-400",
    bgColor: "bg-yellow-500/10",
    icon: Wifi,
    tools: [
      { name: "WiFi Tarayıcı", desc: "Çevredeki tüm kablosuz ağları ve sinyal güçlerini listele" },
      { name: "WPS Tester", desc: "WPS özelliği aktif ağları tespit et ve güvenliğini test et" },
      { name: "Handshake Yakalayıcı", desc: "WPA/WPA2 handshake paketlerini yakala ve analiz et" },
      { name: "Deauth Tester", desc: "Kablosuz ağ güvenliğini deauth testleriyle değerlendir" },
      { name: "SSID Analizi", desc: "Gizli ve açık SSID'leri tespit et, protokolleri analiz et" },
      { name: "Sinyal Haritalama", desc: "Kablosuz ağ sinyal yoğunluğunu görsel olarak haritalandır" },
    ],
  },
  {
    category: "Sosyal Mühendislik",
    subtitle: "Social Engineering",
    color: "from-pink-600/20 to-pink-400/10",
    borderColor: "border-pink-500/30",
    iconColor: "text-pink-400",
    bgColor: "bg-pink-500/10",
    icon: Fingerprint,
    tools: [
      { name: "Phishing Simülatörü", desc: "Eğitim amaçlı phishing sayfaları oluştur ve test et" },
      { name: "E-posta Sahteciliği", desc: "SPF, DKIM ve DMARC yapılandırmalarını kontrol et" },
      { name: "QR Kod Üretici", desc: "Güvenlik testleri için özel QR kodları oluştur" },
      { name: "URL Kısaltıcı & Analiz", desc: "Kısaltılmış URL'lerin gerçek hedefini analiz et" },
      { name: "Pretexting Şablonlar", desc: "Sosyal mühendislik senaryoları için hazır şablonlar" },
      { name: "Awareness Test", desc: "Kurum çalışanlarının güvenlik farkındalığını ölç" },
    ],
  },
  {
    category: "Sistem Araçları",
    subtitle: "System Tools",
    color: "from-cyan-600/20 to-cyan-400/10",
    borderColor: "border-cyan-500/30",
    iconColor: "text-cyan-400",
    bgColor: "bg-cyan-500/10",
    icon: Terminal,
    tools: [
      { name: "İşlem Yöneticisi", desc: "Çalışan işlemleri listele, analiz et ve yönet" },
      { name: "Dosya Hash Kontrolü", desc: "Dosya bütünlüğünü MD5/SHA hash ile doğrula" },
      { name: "Registry Analizi", desc: "Windows registry anahtarlarını güvenlik açısından tara" },
      { name: "Servis Yöneticisi", desc: "Sistem servislerini listele ve güvenlik durumunu analiz et" },
      { name: "Log Analizi", desc: "Sistem loglarını filtrele ve şüpheli aktiviteleri tespit et" },
      { name: "Başlangıç Tarayıcı", desc: "Otomatik başlayan programları listele ve analiz et" },
    ],
  },
  {
    category: "Eğitim & Kaynaklar",
    subtitle: "Educational Resources",
    color: "from-indigo-600/20 to-indigo-400/10",
    borderColor: "border-indigo-500/30",
    iconColor: "text-indigo-400",
    bgColor: "bg-indigo-500/10",
    icon: GraduationCap,
    tools: [
      { name: "CTF Rehberi", desc: "Capture The Flag yarışmaları için kapsamlı çözüm rehberi" },
      { name: "Güvenlik Sözlüğü", desc: "Siber güvenlik terimlerinin Türkçe açıklamalı sözlüğü" },
      { name: "Lab Ortamı", desc: "Güvenli sanal ortamda sızma testi pratiği yap" },
      { name: "Video Dersler", desc: "Araçların kullanımına dair adım adım video eğitimler" },
      { name: "Cheatsheetler", desc: "Komutlar ve teknikler için hızlı referans kartları" },
      { name: "Sertifika Yol Haritası", desc: "CEH, OSCP, CompTIA Security+ için hazırlık rehberleri" },
    ],
  },
];

export function Tools() {
  const { user, setShowAuthModal, setAuthTab } = useAuth();
  const [activeTool, setActiveTool] = useState<{ name: string; desc: string; category: string } | null>(null);

  function handleToolClick(toolName: string, toolDesc: string, categoryName: string) {
    if (!user) {
      setAuthTab("register");
      setShowAuthModal(true);
      return;
    }
    setActiveTool({ name: toolName, desc: toolDesc, category: categoryName });
  }

  return (
    <section id="tools" className="py-24 relative bg-black/50 border-y border-white/5">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMiIgY3k9IjIiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiLz48L3N2Zz4=')] [mask-image:linear-gradient(to_bottom,transparent,black_10%,black_90%,transparent)]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-5xl font-display font-bold mb-4"
          >
            TÜM <span className="text-primary text-glow">ARAÇLAR</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-muted-foreground text-lg"
          >
            9 kategori, 54 araç — siber güvenlik eğitiminiz için eksiksiz toolkit.
          </motion.p>
          {!user && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-primary/10 border border-primary/30 text-primary text-sm font-medium"
            >
              <LockIcon className="w-4 h-4" />
              Araçları kullanmak için giriş yapın veya kayıt olun
            </motion.div>
          )}
        </div>

        <div className="space-y-12">
          {categories.map((cat, catIdx) => (
            <motion.div
              key={cat.category}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: catIdx * 0.05, duration: 0.5 }}
            >
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-10 h-10 rounded-xl ${cat.bgColor} border ${cat.borderColor} flex items-center justify-center`}>
                  <cat.icon className={`w-5 h-5 ${cat.iconColor}`} />
                </div>
                <div>
                  <h3 className="font-display font-bold text-xl text-foreground">{cat.category}</h3>
                  <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider">[{cat.subtitle}]</p>
                </div>
                <div className={`ml-auto px-3 py-1 rounded-full text-xs font-bold ${cat.bgColor} ${cat.iconColor} border ${cat.borderColor}`}>
                  {cat.tools.length} Araç
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {cat.tools.map((tool, toolIdx) => (
                  <motion.div
                    key={tool.name}
                    initial={{ opacity: 0, scale: 0.95 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: catIdx * 0.03 + toolIdx * 0.03 }}
                    onClick={() => handleToolClick(tool.name, tool.desc, cat.category)}
                    className={`group relative bg-card/40 backdrop-blur-sm border border-white/5 hover:${cat.borderColor} rounded-xl p-4 transition-all duration-300 cursor-pointer hover:bg-white/5`}
                  >
                    <div className={`absolute inset-0 bg-gradient-to-br ${cat.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-xl`} />
                    <div className="relative z-10 flex items-start gap-3">
                      <div className={`w-8 h-8 rounded-lg ${cat.bgColor} flex items-center justify-center shrink-0 mt-0.5`}>
                        <Terminal className={`w-4 h-4 ${cat.iconColor}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className={`font-display font-bold text-sm text-foreground group-hover:${cat.iconColor} transition-colors truncate`}>
                            {tool.name}
                          </h4>
                          {!user && <LockIcon className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
                          {user && <ArrowRight className={`w-3.5 h-3.5 ${cat.iconColor} opacity-0 group-hover:opacity-100 transition-opacity shrink-0`} />}
                        </div>
                        <p className="text-xs text-muted-foreground leading-relaxed mt-1">{tool.desc}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <ToolModal tool={activeTool} onClose={() => setActiveTool(null)} />
    </section>
  );
}
