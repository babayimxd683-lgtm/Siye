import { motion } from "framer-motion";
import { MessageCircle, Users, Zap, ChevronRight } from "lucide-react";

export function Discord() {
  return (
    <section id="discord" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(88,101,242,0.12)_0%,transparent_70%)] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#5865F2]/10 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-display font-bold uppercase tracking-widest bg-[#5865F2]/10 text-[#5865F2] border border-[#5865F2]/30 mb-4">
            Topluluk
          </span>
          <h2 className="text-3xl sm:text-4xl font-display font-bold text-foreground mb-4">
            Discord Sunucumuza <span className="text-[#5865F2]">Katıl</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto text-sm leading-relaxed">
            Topluluğumuza katılarak diğer kullanıcılarla iletişim kurun, destek alın ve güncellemelerden haberdar olun.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-2xl mx-auto"
        >
          <div className="bg-[#1e1f2e] border border-[#5865F2]/30 rounded-2xl overflow-hidden shadow-[0_0_60px_rgba(88,101,242,0.15)]">
            {/* Discord Header */}
            <div className="bg-[#5865F2] px-8 py-6 flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
                <MessageCircle className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-white font-display font-bold text-xl">Aethron System</h3>
                <p className="text-white/70 text-sm">Resmi Discord Sunucusu</p>
              </div>
              <div className="ml-auto flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-green-400 animate-pulse" />
                <span className="text-white/80 text-sm font-medium">Çevrimiçi</span>
              </div>
            </div>

            {/* Discord Body */}
            <div className="px-8 py-8 space-y-6">
              <div className="grid grid-cols-3 gap-4">
                {[
                  { icon: Users, label: "Üyeler", value: "500+" },
                  { icon: MessageCircle, label: "Kanallar", value: "10+" },
                  { icon: Zap, label: "Aktif", value: "7/24" },
                ].map(({ icon: Icon, label, value }) => (
                  <div key={label} className="bg-white/5 rounded-xl p-4 text-center border border-white/5">
                    <Icon className="w-5 h-5 text-[#5865F2] mx-auto mb-2" />
                    <div className="text-white font-bold text-lg font-display">{value}</div>
                    <div className="text-muted-foreground text-xs">{label}</div>
                  </div>
                ))}
              </div>

              <div className="space-y-2">
                {["# genel-sohbet", "# destek", "# araç-güncellemeleri", "# siber-güvenlik"].map((channel) => (
                  <div key={channel} className="flex items-center gap-3 px-4 py-2 rounded-lg bg-white/5 text-muted-foreground text-sm hover:text-white hover:bg-white/10 transition-colors cursor-default">
                    <span className="text-[#5865F2] font-mono text-base">#</span>
                    <span>{channel.replace("# ", "")}</span>
                  </div>
                ))}
              </div>

              <a
                href="https://discord.gg/J5VaDwqru"
                target="_blank"
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl font-display font-bold text-white uppercase tracking-wider
                  bg-[#5865F2] hover:bg-[#4752c4] shadow-[0_0_30px_rgba(88,101,242,0.4)] hover:shadow-[0_0_50px_rgba(88,101,242,0.6)]
                  transition-all duration-300 text-sm group"
              >
                <MessageCircle className="w-5 h-5" />
                Discord'a Katıl
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
