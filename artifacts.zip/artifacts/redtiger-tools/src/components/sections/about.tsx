import { motion } from "framer-motion";
import { ShieldCheck, Target, Users } from "lucide-react";

export function About() {
  const features = [
    {
      icon: Target,
      title: "Hedef Odaklı Öğrenim",
      desc: "Kullanıcıların siber güvenlik kavramlarını pratik yaparak öğrenmesi için gerçek dünya senaryolarına uygun tasarlanmıştır."
    },
    {
      icon: ShieldCheck,
      title: "Güvenli ve Kontrollü",
      desc: "Araçlar eğitim ortamlarında kullanılmak üzere sınırlandırılmış ve izole test senaryoları için optimize edilmiştir."
    },
    {
      icon: Users,
      title: "Topluluk Destekli",
      desc: "Geri bildirimlerinizle büyüyen açık kaynaklı bir proje. Github üzerinden katkıda bulunabilir ve hataları bildirebilirsiniz."
    }
  ];

  return (
    <section id="about" className="py-24 relative bg-card/30 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-5"
          >
            <h2 className="text-3xl md:text-5xl font-display font-bold mb-6 uppercase leading-tight">
              Eğitim İçin <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-white">
                Geliştirildi
              </span>
            </h2>
            <div className="w-20 h-1 bg-primary mb-8" />
            
            <p className="text-muted-foreground leading-relaxed mb-6">
              Aethron System projesi, bilgi güvenliği meraklılarına ve öğrencilerine pratik yapma imkanı sunmak amacıyla başlatılmıştır. Amacımız, karmaşık güvenlik testlerini anlaşılır ve ulaşılabilir kılmaktır.
            </p>
            
            <p className="text-muted-foreground leading-relaxed">
              Basit arayüzü ve güçlü altyapısı sayesinde, siber güvenliğe yeni başlayanlardan ileri düzey kullanıcılara kadar geniş bir kitleye hitap eder.
            </p>
          </motion.div>

          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {features.map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className={`p-6 rounded-2xl border border-white/5 bg-background ${idx === 2 ? 'sm:col-span-2 sm:flex sm:items-center sm:gap-6' : ''}`}
              >
                <div className={`w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 shrink-0 ${idx === 2 ? 'sm:mb-0' : ''}`}>
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-lg mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        
      </div>
    </section>
  );
}
