import { motion } from "framer-motion";
import { Terminal, ChevronRight, ShieldCheck, LogIn } from "lucide-react";
import { useAuth } from "@/context/auth-context";

export function Hero() {
  const { user, setShowAuthModal, setAuthTab } = useAuth();

  function handleGetStarted() {
    if (!user) {
      setAuthTab("register");
      setShowAuthModal(true);
    }
  }

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
          alt="Cybersecurity Background"
          className="w-full h-full object-cover opacity-30 mix-blend-screen"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/90 to-background" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(220,38,38,0.15),transparent_50%)]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium tracking-wider uppercase mb-6">
              <Terminal className="w-3.5 h-3.5" />
              <span>v2.3 — 54 Araç, 9 Kategori</span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-display font-bold leading-[1.1] mb-6">
              <span className="block text-foreground">SİBER GÜVENLİĞİ</span>
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent pb-2">
                KEŞFEDİN
              </span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground mb-10 leading-relaxed font-light">
              Aethron System, eğitim amaçlı tasarlanmış 9 kategoride 54 araçlık kapsamlı siber güvenlik platformu. Kayıt ol, araçlara eriş, öğren.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              {user ? (
                <a
                  href="#tools"
                  className="group relative inline-flex items-center justify-center px-8 py-4 font-display font-bold uppercase tracking-widest text-sm rounded-lg overflow-hidden bg-primary text-primary-foreground shadow-[0_0_30px_rgba(220,38,38,0.4)] transition-all hover:scale-105 hover:shadow-[0_0_40px_rgba(220,38,38,0.6)]"
                >
                  <ShieldCheck className="w-5 h-5 mr-2" />
                  Araçlara Git
                </a>
              ) : (
                <button
                  onClick={handleGetStarted}
                  className="group relative inline-flex items-center justify-center px-8 py-4 font-display font-bold uppercase tracking-widest text-sm rounded-lg overflow-hidden bg-primary text-primary-foreground shadow-[0_0_30px_rgba(220,38,38,0.4)] transition-all hover:scale-105 hover:shadow-[0_0_40px_rgba(220,38,38,0.6)]"
                >
                  <LogIn className="w-5 h-5 mr-2" />
                  Ücretsiz Kayıt Ol
                </button>
              )}

              <a
                href="#tools"
                className="inline-flex items-center justify-center px-8 py-4 font-display font-bold uppercase tracking-widest text-sm rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 hover:border-primary/50 text-foreground transition-all duration-300"
              >
                Araçları İncele
                <ChevronRight className="w-4 h-4 ml-2 text-primary" />
              </a>
            </div>

            <div className="flex items-center gap-6 mt-10">
              {[
                { value: "54", label: "Araç" },
                { value: "9", label: "Kategori" },
                { value: "7/24", label: "Erişim" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="font-display font-bold text-2xl text-primary">{stat.value}</div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">{stat.label}</div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
            className="hidden lg:flex justify-center relative"
          >
            <div className="relative w-full aspect-square max-w-md">
              <div className="absolute inset-0 border border-primary/20 rounded-full animate-[spin_60s_linear_infinite] border-dashed" />
              <div className="absolute inset-4 border border-primary/10 rounded-full animate-[spin_40s_linear_infinite_reverse]" />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-64 h-64 rounded-2xl flex items-center justify-center p-8 overflow-hidden group bg-card/50 border border-white/10">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  <img
                    src={`${import.meta.env.BASE_URL}images/logo.png`}
                    alt="RedTiger Logo"
                    className="w-full h-full object-contain filter drop-shadow-[0_0_15px_rgba(220,38,38,0.8)] relative z-10"
                  />
                  <div className="absolute top-0 left-0 w-full h-1 bg-primary/80 shadow-[0_0_15px_rgba(220,38,38,1)] animate-[scan_3s_ease-in-out_infinite]" />
                </div>
              </div>
              <div className="absolute top-10 right-10 bg-card border border-primary/30 p-3 rounded-lg text-xs font-mono text-primary animate-pulse">
                SYS.CHK: OK
              </div>
              <div className="absolute bottom-10 left-10 bg-card border border-primary/30 p-3 rounded-lg text-xs font-mono text-primary">
                NET: SECURE
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
