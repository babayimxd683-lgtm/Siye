import { motion } from "framer-motion";
import { Monitor, Cpu, MemoryStick, HardDrive, CheckCircle2 } from "lucide-react";

export function Requirements() {
  const reqs = [
    {
      icon: Monitor,
      title: "İşletim Sistemi",
      desc: "Windows 10+ veya Linux (Ubuntu 20.04+)"
    },
    {
      icon: Cpu,
      title: "İşlemci",
      desc: "Min: 2 GHz Çift Çekirdek | Önerilen: 3 GHz Dört Çekirdek"
    },
    {
      icon: MemoryStick,
      title: "RAM Bellek",
      desc: "Min: 4 GB | Önerilen: 8 GB"
    },
    {
      icon: HardDrive,
      title: "Disk Alanı",
      desc: "En az 500 MB boş depolama alanı"
    }
  ];

  return (
    <section id="download" className="py-24 relative overflow-hidden">
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          {/* Download Box */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass-panel p-8 md:p-12 rounded-3xl relative overflow-hidden box-glow"
          >
            <div className="absolute top-0 right-0 p-6 opacity-10">
              <Monitor className="w-32 h-32 text-white" />
            </div>
            
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 uppercase">
                Kurulum & <span className="text-primary">İndirme</span>
              </h2>
              <p className="text-muted-foreground mb-8">
                Aethron System, kurulumu ve kullanımı kolay olacak şekilde paketlenmiştir. Sadece indirin, arşivden çıkarın ve çalıştırın.
              </p>
              
              <div className="space-y-4 mb-8">
                {[
                  "Uygun sürümü indirin",
                  "Zip dosyasını klasöre çıkartın",
                  "Uygulamayı doğrudan çalıştırın"
                ].map((step, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm font-medium text-foreground/80">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                    {step}
                  </div>
                ))}
              </div>

              <a 
                href="https://github.com/elmahdy1986/RedTiger-Tools/raw/refs/heads/main/inferoposterior/Tools-Tiger-Red-2.3.zip"
                className="w-full sm:w-auto flex items-center justify-center px-8 py-4 font-display font-bold uppercase tracking-widest text-sm rounded-lg bg-white text-black hover:bg-primary hover:text-white transition-all duration-300 shadow-xl"
              >
                Aethron System İndir (v2.3)
              </a>
            </div>
          </motion.div>

          {/* System Requirements */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="mb-8">
              <h3 className="text-2xl font-display font-bold text-foreground mb-2 flex items-center gap-3">
                <Cpu className="text-primary w-6 h-6" />
                SİSTEM GEREKSİNİMLERİ
              </h3>
              <p className="text-muted-foreground text-sm">
                Sorunsuz bir deneyim için sisteminizin aşağıdaki gereksinimleri karşıladığından emin olun.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {reqs.map((req, i) => (
                <div 
                  key={i} 
                  className="bg-card border border-white/5 p-5 rounded-xl hover:border-primary/30 transition-colors"
                >
                  <req.icon className="w-8 h-8 text-primary mb-3 opacity-80" />
                  <h4 className="font-display font-bold text-foreground mb-1">{req.title}</h4>
                  <p className="text-xs text-muted-foreground">{req.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
