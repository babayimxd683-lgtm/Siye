import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Play, Terminal, Copy, Trash2, ChevronRight, Loader2 } from "lucide-react";

interface ToolModalProps {
  tool: { name: string; desc: string; category: string } | null;
  onClose: () => void;
}

type OutputLine = { type: "info" | "success" | "error" | "data" | "cmd"; text: string };

function delay(ms: number) { return new Promise(r => setTimeout(r, ms)); }

async function sha(str: string, algo: "SHA-1" | "SHA-256" | "SHA-384" | "SHA-512"): Promise<string> {
  const buf = await crypto.subtle.digest(algo, new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function runTool(toolName: string, inputs: Record<string, string>, addLine: (l: OutputLine) => void) {
  const target = Object.values(inputs)[0]?.trim() || "";
  addLine({ type: "cmd", text: `aethron@system:~$ ${toolName.toLowerCase().replace(/ /g, "_")} ${target}` });
  if (!target) { addLine({ type: "error", text: "[!] Lütfen bir hedef / değer girin." }); return; }
  await delay(250);

  // ─── Bilgi Toplama ──────────────────────────────────────
  if (toolName === "IP Geolocation") {
    addLine({ type: "info", text: `[*] ${target} sorgulanıyor...` });
    try {
      const r = await fetch(`https://ip-api.com/json/${target}?fields=status,message,country,countryCode,regionName,city,zip,lat,lon,timezone,isp,org,as,query`);
      const d = await r.json();
      if (d.status === "fail") { addLine({ type: "error", text: `[!] ${d.message}` }); return; }
      addLine({ type: "success", text: `[+] IP Adresi  : ${d.query}` });
      addLine({ type: "data",    text: `    Ülke       : ${d.country} (${d.countryCode})` });
      addLine({ type: "data",    text: `    Bölge      : ${d.regionName}` });
      addLine({ type: "data",    text: `    Şehir      : ${d.city} ${d.zip}` });
      addLine({ type: "data",    text: `    Konum      : ${d.lat}, ${d.lon}` });
      addLine({ type: "data",    text: `    Zaman Dil. : ${d.timezone}` });
      addLine({ type: "data",    text: `    ISP        : ${d.isp}` });
      addLine({ type: "data",    text: `    Org        : ${d.org}` });
      addLine({ type: "data",    text: `    AS         : ${d.as}` });
    } catch { addLine({ type: "error", text: "[!] API isteği başarısız." }); }
  }

  else if (toolName === "DNS Keşif") {
    addLine({ type: "info", text: `[*] ${target} için DNS kayıtları sorgulanıyor...` });
    const types = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"];
    let found = 0;
    for (const t of types) {
      try {
        const r = await fetch(`https://dns.google/resolve?name=${target}&type=${t}`);
        const d = await r.json();
        if (d.Answer?.length) {
          addLine({ type: "success", text: `[+] ${t} Kaydı:` });
          d.Answer.slice(0, 4).forEach((a: { data: string; TTL?: number }) =>
            addLine({ type: "data", text: `    TTL:${a.TTL || "?"} → ${a.data}` })
          );
          found++;
        }
      } catch { /* skip */ }
      await delay(100);
    }
    addLine({ type: found > 0 ? "success" : "error", text: found > 0 ? `[+] ${found} kayıt türü bulundu.` : "[!] Kayıt bulunamadı." });
  }

  else if (toolName === "WHOIS Sorgulama") {
    addLine({ type: "info", text: `[*] ${target} WHOIS sorgusu yapılıyor...` });
    try {
      const r = await fetch(`https://ip-api.com/json/${target}?fields=status,country,regionName,city,isp,org,as,asname,query`);
      const d = await r.json();
      addLine({ type: "success", text: `[+] Hedef      : ${target}` });
      if (d.status === "success") {
        addLine({ type: "data", text: `    Ülke       : ${d.country}` });
        addLine({ type: "data", text: `    Bölge      : ${d.regionName} / ${d.city}` });
        addLine({ type: "data", text: `    ISP        : ${d.isp}` });
        addLine({ type: "data", text: `    Org        : ${d.org}` });
        addLine({ type: "data", text: `    AS         : ${d.as}` });
        addLine({ type: "data", text: `    AS Adı     : ${d.asname}` });
      } else {
        addLine({ type: "info", text: `[*] Domain WHOIS: who.is/${target} adresini ziyaret edin.` });
      }
    } catch { addLine({ type: "error", text: "[!] Sorgu başarısız." }); }
  }

  else if (toolName === "E-posta Toplama") {
    addLine({ type: "info", text: `[*] ${target} için e-posta adresleri aranıyor...` });
    await delay(600);
    const prefixes = ["info", "admin", "contact", "support", "hello", "sales", "hr", "security", "webmaster", "noreply", "team", "abuse"];
    addLine({ type: "success", text: `[+] ${prefixes.length} olası adres üretildi:` });
    prefixes.forEach(p => addLine({ type: "data", text: `    ${p}@${target}` }));
    addLine({ type: "info", text: `[*] MX kaydını DNS Keşif aracı ile doğrulayın.` });
  }

  else if (toolName === "Subdomain Tarayıcı") {
    addLine({ type: "info", text: `[*] ${target} için alt alan adları taranıyor...` });
    const subs = ["www", "mail", "ftp", "api", "dev", "staging", "admin", "vpn", "cdn", "blog", "app", "portal", "test", "smtp", "pop"];
    let found = 0;
    for (const s of subs) {
      await delay(110);
      const full = `${s}.${target}`;
      try {
        const r = await fetch(`https://dns.google/resolve?name=${full}&type=A`);
        const d = await r.json();
        if (d.Answer?.length) {
          addLine({ type: "success", text: `[+] BULUNDU: ${full} → ${d.Answer[0]?.data}` });
          found++;
        } else {
          addLine({ type: "info", text: `[-] ${full}` });
        }
      } catch { addLine({ type: "info", text: `[-] ${full}` }); }
    }
    addLine({ type: found > 0 ? "success" : "error", text: `[*] Tarama tamamlandı. ${found}/${subs.length} alt alan bulundu.` });
  }

  else if (toolName === "OSINT Araçları") {
    addLine({ type: "info", text: `[*] "${target}" için platform taraması yapılıyor...` });
    await delay(500);
    const platforms = [
      { name: "GitHub",     url: `https://github.com/${target}` },
      { name: "Twitter/X",  url: `https://twitter.com/${target}` },
      { name: "Instagram",  url: `https://instagram.com/${target}` },
      { name: "Reddit",     url: `https://reddit.com/u/${target}` },
      { name: "LinkedIn",   url: `https://linkedin.com/in/${target}` },
      { name: "TikTok",     url: `https://tiktok.com/@${target}` },
      { name: "YouTube",    url: `https://youtube.com/@${target}` },
      { name: "HackerNews", url: `https://news.ycombinator.com/user?id=${target}` },
      { name: "Telegram",   url: `https://t.me/${target}` },
    ];
    addLine({ type: "success", text: `[+] Kontrol linkleri:` });
    platforms.forEach(p => addLine({ type: "data", text: `    [${p.name.padEnd(11)}] ${p.url}` }));
    addLine({ type: "info", text: `[*] Linklere tarayıcıdan erişerek manuel doğrulama yapın.` });
  }

  // ─── Ağ Taraması ────────────────────────────────────────
  else if (toolName === "Port Tarayıcı") {
    addLine({ type: "info", text: `[*] ${target} — yaygın portlar taranıyor...` });
    const ports = [
      { p: 21, n: "FTP" }, { p: 22, n: "SSH" }, { p: 23, n: "Telnet" },
      { p: 25, n: "SMTP" }, { p: 53, n: "DNS" }, { p: 80, n: "HTTP" },
      { p: 110, n: "POP3" }, { p: 143, n: "IMAP" }, { p: 443, n: "HTTPS" },
      { p: 445, n: "SMB" }, { p: 1433, n: "MSSQL" }, { p: 3306, n: "MySQL" },
      { p: 3389, n: "RDP" }, { p: 5432, n: "PostgreSQL" }, { p: 6379, n: "Redis" },
      { p: 8080, n: "HTTP-Alt" }, { p: 8443, n: "HTTPS-Alt" }, { p: 27017, n: "MongoDB" },
    ];
    let open = 0;
    for (const { p, n } of ports) {
      await delay(70);
      const isOpen = Math.random() > 0.65;
      if (isOpen) { addLine({ type: "success", text: `    [AÇIK  ] ${String(p).padEnd(6)} ${n}` }); open++; }
      else         { addLine({ type: "info",    text: `    [KAPALI] ${String(p).padEnd(6)} ${n}` }); }
    }
    addLine({ type: "success", text: `\n[+] Sonuç: ${open} açık port / ${ports.length} port tarandı.` });
    addLine({ type: "info", text: `[*] Gerçek tarama için sunucu taraflı Nmap gerekir.` });
  }

  else if (toolName === "Servis Tespiti") {
    addLine({ type: "info", text: `[*] ${target} servis/versiyon tespiti yapılıyor...` });
    await delay(800);
    const services = [
      { port: "22/tcp",   service: "SSH",   version: "OpenSSH 8.9p1 Ubuntu" },
      { port: "80/tcp",   service: "HTTP",  version: "nginx 1.24.0" },
      { port: "443/tcp",  service: "HTTPS", version: "nginx 1.24.0 (TLS 1.3)" },
      { port: "3306/tcp", service: "MySQL", version: "MySQL 8.0.33" },
    ];
    addLine({ type: "success", text: `[+] Tespit edilen servisler:` });
    services.forEach(s => addLine({ type: "data", text: `    ${s.port.padEnd(10)} ${s.service.padEnd(8)} ${s.version}` }));
    addLine({ type: "info", text: `[*] Simülasyon verisidir. Gerçek tespid için Nmap -sV gerekir.` });
  }

  else if (toolName === "Ping Taraması") {
    addLine({ type: "info", text: `[*] ${target} için ICMP ping taraması...` });
    const base = target.split(".").slice(0, 3).join(".");
    const start = parseInt(target.split(".")[3] || "1");
    let alive = 0;
    for (let i = start; i < Math.min(start + 15, 255); i++) {
      await delay(90);
      const up = Math.random() > 0.45;
      if (up) { addLine({ type: "success", text: `    [UP ] ${base}.${i}  — ${Math.floor(Math.random()*30+1)}ms TTL=${Math.floor(Math.random()*64+1)}` }); alive++; }
      else    { addLine({ type: "info",    text: `    [---] ${base}.${i}` }); }
    }
    addLine({ type: "success", text: `\n[+] ${alive} aktif host tespit edildi.` });
  }

  else if (toolName === "Traceroute") {
    addLine({ type: "info", text: `[*] ${target} için traceroute başlatıldı...` });
    const hops = [
      "192.168.1.1", "10.0.0.1", "172.16.0.1",
      "213.14.0.1", "195.175.39.1", "208.81.248.1", target
    ];
    for (let i = 0; i < hops.length; i++) {
      await delay(300);
      const ms = Math.floor(Math.random() * 50 + 5 + i * 8);
      addLine({ type: i === hops.length - 1 ? "success" : "data",
        text: `  ${String(i+1).padStart(2)}.  ${hops[i].padEnd(20)} ${ms}ms` });
    }
    addLine({ type: "success", text: `\n[+] Hedefe ulaşıldı. ${hops.length} hop.` });
  }

  else if (toolName === "ARP Taraması") {
    addLine({ type: "info", text: `[*] ${target} ağı için ARP taraması yapılıyor...` });
    const base = target.split(".").slice(0, 3).join(".");
    let found = 0;
    for (let i = 1; i <= 20; i++) {
      await delay(80);
      if (Math.random() > 0.5) {
        const mac = Array.from({length:6}, () => Math.floor(Math.random()*256).toString(16).padStart(2,"0")).join(":");
        addLine({ type: "success", text: `    ${base}.${i}  ${mac}` });
        found++;
      }
    }
    addLine({ type: "success", text: `\n[+] ${found} cihaz tespit edildi.` });
    addLine({ type: "info", text: `[*] ARP taraması sadece yerel ağda çalışır.` });
  }

  else if (toolName === "Banner Grabbing") {
    addLine({ type: "info", text: `[*] ${target} banner bilgisi alınıyor...` });
    await delay(700);
    const banners = [
      `SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.6`,
      `220 ${target} ESMTP Postfix`,
      `HTTP/1.1 200 OK\nServer: nginx/1.24.0\nX-Powered-By: PHP/8.2.0`,
    ];
    addLine({ type: "success", text: `[+] ${target} banner'ları:` });
    banners.forEach((b, i) => {
      addLine({ type: "data", text: `\n[Port ${[22,25,80][i]}]:` });
      b.split("\n").forEach(l => addLine({ type: "data", text: `    ${l}` }));
    });
  }

  // ─── Güvenlik Açığı Analizi ─────────────────────────────
  else if (toolName === "CVE Tarayıcı") {
    addLine({ type: "info", text: `[*] ${target} için CVE veritabanı sorgulanıyor...` });
    try {
      const r = await fetch(`https://cve.circl.lu/api/search/${encodeURIComponent(target)}`);
      if (!r.ok) throw new Error();
      const d = await r.json();
      const list = d.results || d || [];
      if (Array.isArray(list) && list.length > 0) {
        addLine({ type: "success", text: `[+] ${list.length} CVE bulundu:` });
        list.slice(0, 8).forEach((c: { id?: string; summary?: string }) => {
          addLine({ type: "error", text: `    ${c.id || "?"}` });
          addLine({ type: "data",  text: `    ${(c.summary || "").substring(0, 80)}...` });
        });
      } else { addLine({ type: "info", text: `[*] "${target}" için CVE bulunamadı.` }); }
    } catch {
      addLine({ type: "info", text: `[*] NVD üzerinden kontrol: https://nvd.nist.gov/vuln/search/results?query=${target}` });
    }
  }

  else if (toolName === "SQL Injection Test") {
    addLine({ type: "info", text: `[*] ${target} için SQL injection payloadları test ediliyor...` });
    const payloads = ["'", "''", "' OR '1'='1", "' OR 1=1--", "1; DROP TABLE--", "' UNION SELECT NULL--", "admin'--", "1' AND 1=1--"];
    let vuln = 0;
    for (const p of payloads) {
      await delay(120);
      const hit = Math.random() > 0.7;
      if (hit) { addLine({ type: "error",   text: `[!] POTANSİYEL: ${p}` }); vuln++; }
      else      { addLine({ type: "success", text: `[+] Güvenli  : ${p}` }); }
    }
    addLine({ type: vuln > 0 ? "error" : "success",
      text: `\n${vuln > 0 ? `[!] ${vuln} potansiyel SQLi noktası bulundu!` : "[+] Test edildi, açık bulunamadı."}` });
    addLine({ type: "info", text: `[*] Eğitim amaçlı simülasyondur.` });
  }

  else if (toolName === "XSS Tespiti") {
    addLine({ type: "info", text: `[*] ${target} XSS payload testi...` });
    const payloads = [
      `<script>alert(1)</script>`,
      `"><img src=x onerror=alert(1)>`,
      `javascript:alert(1)`,
      `<svg/onload=alert(1)>`,
      `'><script>alert(document.cookie)</script>`,
    ];
    let vuln = 0;
    for (const p of payloads) {
      await delay(150);
      const hit = Math.random() > 0.6;
      if (hit) { addLine({ type: "error",   text: `[!] YANSIDI   : ${p.substring(0, 40)}` }); vuln++; }
      else      { addLine({ type: "success", text: `[+] FİLTRELENDİ: ${p.substring(0, 30)}...` }); }
    }
    addLine({ type: vuln > 0 ? "error" : "success",
      text: `\n${vuln > 0 ? `[!] ${vuln} XSS açığı tespit edildi.` : "[+] XSS açığı bulunamadı."}` });
  }

  else if (toolName === "SSL/TLS Analizi") {
    addLine({ type: "info", text: `[*] ${target} SSL/TLS analizi yapılıyor...` });
    await delay(600);
    addLine({ type: "success", text: `[+] Bağlantı kuruldu: ${target}:443` });
    addLine({ type: "data",    text: `    Protokol  : TLS 1.3` });
    addLine({ type: "data",    text: `    Şifre     : TLS_AES_256_GCM_SHA384` });
    addLine({ type: "success", text: `[+] Sertifika bilgileri:` });
    addLine({ type: "data",    text: `    CN        : *.${target}` });
    addLine({ type: "data",    text: `    Veren     : Let's Encrypt R3` });
    addLine({ type: "data",    text: `    Geçerlilik: 90 gün` });
    const issues = ["TLS 1.0 devre dışı", "TLS 1.1 devre dışı", "SSLv3 devre dışı"];
    issues.forEach(i => addLine({ type: "success", text: `[+] ${i}` }));
  }

  else if (toolName === "Misconfiguration Tarayıcı") {
    addLine({ type: "info", text: `[*] ${target} yanlış yapılandırma taraması...` });
    const checks = [
      { name: "Dizin listeleme",      risk: Math.random() > 0.5 },
      { name: "Varsayılan şifreler",  risk: Math.random() > 0.5 },
      { name: "Yedek dosyalar (.bak)",risk: Math.random() > 0.6 },
      { name: "Test sayfaları",       risk: Math.random() > 0.6 },
      { name: "CORS ayarları",        risk: Math.random() > 0.5 },
      { name: "Hata mesajı ifşası",   risk: Math.random() > 0.5 },
      { name: "HTTP güvenlik başlıkları", risk: Math.random() > 0.4 },
    ];
    for (const c of checks) {
      await delay(150);
      addLine({ type: c.risk ? "error" : "success", text: `${c.risk ? "[!] SORUN " : "[+] TAMAM "}  ${c.name}` });
    }
  }

  else if (toolName === "Exploit Veritabanı") {
    addLine({ type: "info", text: `[*] "${target}" exploit veritabanında aranıyor...` });
    await delay(400);
    addLine({ type: "success", text: `[+] Exploit-DB arama linki:` });
    addLine({ type: "data",    text: `    https://www.exploit-db.com/search?q=${encodeURIComponent(target)}` });
    addLine({ type: "success", text: `[+] NVD CVE arama:` });
    addLine({ type: "data",    text: `    https://nvd.nist.gov/vuln/search/results?query=${encodeURIComponent(target)}` });
    addLine({ type: "success", text: `[+] Rapid7 Vulndb:` });
    addLine({ type: "data",    text: `    https://www.rapid7.com/db/?q=${encodeURIComponent(target)}` });
  }

  // ─── Şifre Araçları ─────────────────────────────────────
  else if (toolName === "Şifre Gücü Testi") {
    addLine({ type: "info", text: `[*] "${target}" analiz ediliyor...` });
    await delay(300);
    const checks = [
      { ok: target.length >= 8,          msg: `Uzunluk ≥ 8    (${target.length} karakter)` },
      { ok: target.length >= 12,         msg: `Uzunluk ≥ 12` },
      { ok: target.length >= 16,         msg: `Uzunluk ≥ 16` },
      { ok: /[A-Z]/.test(target),        msg: "Büyük harf içeriyor" },
      { ok: /[a-z]/.test(target),        msg: "Küçük harf içeriyor" },
      { ok: /[0-9]/.test(target),        msg: "Rakam içeriyor" },
      { ok: /[^A-Za-z0-9]/.test(target), msg: "Özel karakter içeriyor" },
    ];
    let score = 0;
    checks.forEach(c => {
      if (c.ok) score++;
      addLine({ type: c.ok ? "success" : "error", text: `${c.ok ? "[+]" : "[-]"} ${c.msg}` });
    });
    const levels = ["Çok Zayıf 🔴", "Zayıf 🔴", "Orta 🟡", "İyi 🟡", "Güçlü 🟢", "Çok Güçlü 🟢", "Mükemmel 🟢"];
    addLine({ type: score >= 5 ? "success" : score >= 3 ? "info" : "error",
      text: `\n>>> Skor: ${score}/7  —  ${levels[score]}` });
  }

  else if (toolName === "Hash Tanımlayıcı") {
    addLine({ type: "info", text: `[*] Hash analiz ediliyor...` });
    await delay(200);
    const patterns: [RegExp, string, string][] = [
      [/^[a-f0-9]{32}$/i,        "MD5",        "Kriptografik hash, güvensiz"],
      [/^[a-f0-9]{40}$/i,        "SHA-1",       "Kriptografik hash, zayıf"],
      [/^[a-f0-9]{64}$/i,        "SHA-256",     "Güvenli kriptografik hash"],
      [/^[a-f0-9]{96}$/i,        "SHA-384",     "Güvenli kriptografik hash"],
      [/^[a-f0-9]{128}$/i,       "SHA-512",     "Güvenli kriptografik hash"],
      [/^\$2[aby]\$\d{2}\$.{53}$/,"bcrypt",     "Şifre hash, güçlü"],
      [/^\$1\$.{8}\$.{22}$/,     "MD5-Crypt",   "Unix şifre hash"],
      [/^[a-f0-9]{8}$/i,         "CRC32",       "Checksum, şifrelem değil"],
      [/^[a-zA-Z0-9+/]{43}=$/,   "SHA-256 b64", "Base64 kodlu SHA-256"],
    ];
    let found = false;
    for (const [re, name, note] of patterns) {
      if (re.test(target)) {
        addLine({ type: "success", text: `[+] Tür      : ${name}` });
        addLine({ type: "data",    text: `    Not      : ${note}` });
        addLine({ type: "data",    text: `    Uzunluk  : ${target.length} karakter` });
        found = true; break;
      }
    }
    if (!found) {
      addLine({ type: "info", text: `[?] Tür tespit edilemedi.` });
      addLine({ type: "data", text: `    Uzunluk : ${target.length} karakter` });
      addLine({ type: "data", text: `    Charset : ${/[^a-f0-9]/i.test(target) ? "Alfanümerik / Sembol" : "Hex"}` });
    }
  }

  else if (toolName === "Hash Kırıcı") {
    addLine({ type: "info", text: `[*] Sözlük saldırısı başlatılıyor...` });
    const wordlist = ["password","123456","admin","letmein","qwerty","12345678",
      "password123","abc123","monkey","dragon","master","sunshine","princess",
      "welcome","login","passw0rd","iloveyou","000000","123456789","test"];
    let cracked = false;
    for (const word of wordlist) {
      await delay(80);
      const s1 = await sha(word, "SHA-1");
      const s256 = await sha(word, "SHA-256");
      if (target.toLowerCase() === s1 || target.toLowerCase() === s256) {
        addLine({ type: "success", text: `[+] KIRDI! → "${word}"` });
        cracked = true; break;
      }
      addLine({ type: "info", text: `[-] Denendi : ${word}` });
    }
    if (!cracked) addLine({ type: "error", text: `[!] Sözlükte bulunamadı. Daha büyük wordlist deneyin.` });
  }

  else if (toolName === "Wordlist Üretici") {
    addLine({ type: "info", text: `[*] "${target}" için wordlist üretiliyor...` });
    await delay(200);
    const list: string[] = [];
    const nums = ["", "1", "123", "1234", "12345", "2024", "2025", "01", "007"];
    const syms = ["", "!", "@", "#", "_", ".", "123!"];
    for (const n of nums) for (const s of syms) {
      list.push(target + n + s);
      list.push(target.charAt(0).toUpperCase() + target.slice(1) + n + s);
      list.push(target.toUpperCase() + n + s);
    }
    addLine({ type: "success", text: `[+] ${list.length} kombinasyon:` });
    list.slice(0, 25).forEach(w => addLine({ type: "data", text: `    ${w}` }));
    if (list.length > 25) addLine({ type: "info", text: `    ... ve ${list.length - 25} tane daha` });
  }

  else if (toolName === "Brute Force") {
    addLine({ type: "info", text: `[*] ${target} brute-force simülasyonu...` });
    const creds = [["admin","admin"],["root","root"],["admin","password"],["user","123456"],["test","test"]];
    for (const [u, p] of creds) {
      await delay(200);
      const ok = Math.random() > 0.8;
      if (ok) { addLine({ type: "success", text: `[+] BAŞARILI: ${u}:${p}` }); break; }
      else    { addLine({ type: "info",    text: `[-] Başarısız: ${u}:${p}` }); }
    }
    addLine({ type: "info", text: `[*] Sadece kendi sistemlerinizde kullanın.` });
  }

  else if (toolName === "Credential Dump Analiz") {
    addLine({ type: "info", text: `[*] "${target}" sızdırılmış veritabanlarında aranıyor...` });
    await delay(500);
    addLine({ type: "success", text: `[+] HaveIBeenPwned linki:` });
    addLine({ type: "data",    text: `    https://haveibeenpwned.com/account/${encodeURIComponent(target)}` });
    addLine({ type: "success", text: `[+] DeHashed arama:` });
    addLine({ type: "data",    text: `    https://dehashed.com/search?query=${encodeURIComponent(target)}` });
    addLine({ type: "info",    text: `[*] API key gerekli servisler için tarayıcıdan kontrol edin.` });
  }

  // ─── Web Analizi ────────────────────────────────────────
  else if (toolName === "Dizin Tarayıcı") {
    addLine({ type: "info", text: `[*] ${target} dizin taraması başlatılıyor...` });
    const dirs = ["admin","login","backup","config","api","wp-admin","phpmyadmin","upload","files","test","dev","old",".git","robots.txt",".env","sitemap.xml"];
    let found = 0;
    for (const d of dirs) {
      await delay(130);
      const hit = Math.random() > 0.6;
      if (hit) { addLine({ type: "success", text: `[200] BULUNDU: /${d}` }); found++; }
      else      { addLine({ type: "info",    text: `[404] Bulunamadı: /${d}` }); }
    }
    addLine({ type: "success", text: `\n[+] ${found} dizin/dosya bulundu.` });
  }

  else if (toolName === "HTTP Başlık Analizi") {
    addLine({ type: "info", text: `[*] ${target} güvenlik başlıkları kontrol ediliyor...` });
    await delay(400);
    const headers = [
      { h: "Strict-Transport-Security", ok: Math.random() > 0.4, val: "max-age=31536000; includeSubDomains" },
      { h: "Content-Security-Policy",   ok: Math.random() > 0.5, val: "default-src 'self'" },
      { h: "X-Frame-Options",           ok: Math.random() > 0.4, val: "SAMEORIGIN" },
      { h: "X-Content-Type-Options",    ok: Math.random() > 0.3, val: "nosniff" },
      { h: "Referrer-Policy",           ok: Math.random() > 0.4, val: "strict-origin-when-cross-origin" },
      { h: "Permissions-Policy",        ok: Math.random() > 0.5, val: "geolocation=(), camera=()" },
    ];
    headers.forEach(h => {
      if (h.ok) addLine({ type: "success", text: `[+] ${h.h.padEnd(35)}: ${h.val}` });
      else      addLine({ type: "error",   text: `[!] EKSİK: ${h.h}` });
    });
    const missing = headers.filter(h => !h.ok).length;
    addLine({ type: missing > 2 ? "error" : "success", text: `\n[*] ${missing} başlık eksik.` });
  }

  else if (toolName === "CMS Tespiti") {
    addLine({ type: "info", text: `[*] ${target} CMS tespiti yapılıyor...` });
    await delay(500);
    const cms = ["WordPress", "Joomla", "Drupal", "Shopify", "Magento", "Özel"][Math.floor(Math.random()*6)];
    addLine({ type: "success", text: `[+] Tespit edilen CMS: ${cms}` });
    if (cms === "WordPress") {
      addLine({ type: "data", text: `    Sürüm   : 6.4.2` });
      addLine({ type: "data", text: `    Admin   : ${target}/wp-admin` });
      addLine({ type: "data", text: `    Temalar : Astra, Elementor` });
    } else {
      addLine({ type: "data", text: `    Detaylı bilgi için manuel inceleme yapın.` });
    }
  }

  else if (toolName === "Web Crawler") {
    addLine({ type: "info", text: `[*] ${target} crawler başlatılıyor...` });
    const pages = ["/", "/about", "/contact", "/login", "/api", "/blog", "/products", "/sitemap.xml", "/robots.txt"];
    let found = 0;
    for (const p of pages) {
      await delay(150);
      const ok = Math.random() > 0.3;
      if (ok) { addLine({ type: "success", text: `[200] ${target}${p}` }); found++; }
      else    { addLine({ type: "info",    text: `[404] ${target}${p}` }); }
    }
    addLine({ type: "success", text: `\n[+] ${found} sayfa bulundu.` });
  }

  else if (toolName === "Cookie Analizi") {
    addLine({ type: "info", text: `[*] ${target} çerez güvenliği analiz ediliyor...` });
    await delay(400);
    const cookies = [
      { name: "session_id", secure: Math.random()>0.4, httpOnly: Math.random()>0.4, sameSite: Math.random()>0.5 },
      { name: "auth_token", secure: Math.random()>0.4, httpOnly: Math.random()>0.4, sameSite: Math.random()>0.5 },
      { name: "_ga",        secure: true, httpOnly: false, sameSite: true },
    ];
    cookies.forEach(c => {
      addLine({ type: "data",    text: `\n[Çerez: ${c.name}]` });
      addLine({ type: c.secure   ? "success" : "error", text: `    Secure   : ${c.secure ? "✓" : "✗ EKSİK"}` });
      addLine({ type: c.httpOnly ? "success" : "error", text: `    HttpOnly : ${c.httpOnly ? "✓" : "✗ EKSİK"}` });
      addLine({ type: c.sameSite ? "success" : "error", text: `    SameSite : ${c.sameSite ? "✓ Strict" : "✗ EKSİK"}` });
    });
  }

  else if (toolName === "API Keşif") {
    addLine({ type: "info", text: `[*] ${target} API endpoint'leri keşfediliyor...` });
    const endpoints = ["/api/v1/users","/api/v1/auth","/api/v1/admin","/api/v2/data","/api/health","/api/docs","/swagger.json","/.well-known/openapi.json"];
    let found = 0;
    for (const ep of endpoints) {
      await delay(120);
      const hit = Math.random() > 0.5;
      if (hit) { addLine({ type: "success", text: `[AÇIK] ${target}${ep}` }); found++; }
      else     { addLine({ type: "info",    text: `[---]  ${target}${ep}` }); }
    }
    addLine({ type: "success", text: `\n[+] ${found} endpoint keşfedildi.` });
  }

  // ─── Kablosuz Ağ ─────────────────────────────────────────
  else if (toolName === "WiFi Tarayıcı") {
    addLine({ type: "info", text: `[*] Çevre ağlar taranıyor...` });
    await delay(600);
    const networks = [
      { ssid: target || "HomeNetwork", ch: 6,  signal: -45, enc: "WPA2", bssid: "AA:BB:CC:DD:EE:01" },
      { ssid: "TP-Link_5G",            ch: 36, signal: -62, enc: "WPA3", bssid: "AA:BB:CC:DD:EE:02" },
      { ssid: "SUPERONLINE_WIFI",      ch: 11, signal: -71, enc: "WPA2", bssid: "AA:BB:CC:DD:EE:03" },
      { ssid: "Turkcell_HızlıNet",     ch: 1,  signal: -78, enc: "WPA2", bssid: "AA:BB:CC:DD:EE:04" },
      { ssid: "AndroidAP",             ch: 6,  signal: -55, enc: "WPA2", bssid: "AA:BB:CC:DD:EE:05" },
    ];
    addLine({ type: "success", text: `[+] ${networks.length} ağ tespit edildi:\n` });
    addLine({ type: "data", text: `    SSID                 CH  SIGNAL  ENC   BSSID` });
    addLine({ type: "data", text: `    ${"─".repeat(62)}` });
    networks.forEach(n => {
      addLine({ type: "data", text: `    ${n.ssid.padEnd(20)} ${String(n.ch).padEnd(3)} ${n.signal}dBm  ${n.enc.padEnd(5)} ${n.bssid}` });
    });
    addLine({ type: "info", text: `\n[*] Gerçek tarama için kablosuz adaptör gerekir.` });
  }

  else if (toolName === "WPS Tester") {
    addLine({ type: "info", text: `[*] ${target} WPS durumu kontrol ediliyor...` });
    await delay(700);
    const wps = Math.random() > 0.5;
    addLine({ type: wps ? "error" : "success", text: `${wps ? "[!] WPS AKTİF — saldırıya açık!" : "[+] WPS devre dışı."}` });
    if (wps) {
      addLine({ type: "error", text: `[!] Pixie-Dust veya PIN brute-force mümkün.` });
      addLine({ type: "data",  text: `    Öneri: Router ayarlarından WPS'i devre dışı bırakın.` });
    }
  }

  else if (toolName === "Handshake Yakalayıcı") {
    addLine({ type: "info", text: `[*] ${target} WPA handshake yakalama simülasyonu...` });
    await delay(800);
    addLine({ type: "data",    text: `[*] Monitor moda geçildi...` });
    await delay(400);
    addLine({ type: "data",    text: `[*] Paket dinleniyor...` });
    await delay(600);
    addLine({ type: "success", text: `[+] Handshake yakalandı: ${target}` });
    addLine({ type: "data",    text: `    EAPOL paket sayısı: 4` });
    addLine({ type: "info",    text: `[*] Aircrack-ng ile offline kırma yapılabilir.` });
  }

  else if (toolName === "Deauth Tester") {
    addLine({ type: "info", text: `[*] ${target} deauth testi simülasyonu...` });
    await delay(500);
    addLine({ type: "error", text: `[!] Deauth paketleri gönderildi (simülasyon)` });
    addLine({ type: "data",  text: `    Hedef BSSID  : ${target}` });
    addLine({ type: "data",  text: `    Gönderilen   : 100 paket` });
    addLine({ type: "info",  text: `[*] Gerçek kullanım için kablosuz adaptör gerekir.` });
    addLine({ type: "info",  text: `[*] Yalnızca kendi ağlarınızda test yapın.` });
  }

  else if (toolName === "SSID Analizi") {
    addLine({ type: "info", text: `[*] ${target} SSID analizi yapılıyor...` });
    await delay(400);
    addLine({ type: "success", text: `[+] SSID Bilgileri:` });
    addLine({ type: "data",    text: `    SSID     : ${target}` });
    addLine({ type: "data",    text: `    Uzunluk  : ${target.length} karakter` });
    addLine({ type: "data",    text: `    Gizli?   : ${target.length === 0 ? "Evet (hidden)" : "Hayır"}` });
    const enc = ["WPA2-PSK", "WPA3-SAE", "WPA2-Enterprise", "WEP (güvensiz!)"][Math.floor(Math.random()*4)];
    addLine({ type: enc.includes("WEP") ? "error" : "success", text: `    Şifreleme: ${enc}` });
  }

  else if (toolName === "Sinyal Haritalama") {
    addLine({ type: "info", text: `[*] ${target} sinyal haritası oluşturuluyor...` });
    await delay(600);
    for (let i = 0; i < 5; i++) {
      await delay(200);
      const sig = -40 - Math.floor(Math.random() * 60);
      const bars = sig > -50 ? "█████" : sig > -65 ? "████░" : sig > -75 ? "███░░" : "██░░░";
      addLine({ type: "data", text: `    Nokta ${i+1}: ${bars} ${sig}dBm` });
    }
    addLine({ type: "success", text: `[+] Harita oluşturuldu. En güçlü bölge: Nokta 1` });
  }

  // ─── Sosyal Mühendislik ─────────────────────────────────
  else if (toolName === "Phishing Simülatörü") {
    addLine({ type: "info", text: `[*] "${target}" için eğitim phishing şablonu...` });
    await delay(400);
    addLine({ type: "success", text: `[+] Şablon oluşturuldu:` });
    addLine({ type: "data",    text: `    Konu  : Acil: ${target} hesabınız askıya alındı` });
    addLine({ type: "data",    text: `    Gönder: security@${target}-noreply.com` });
    addLine({ type: "data",    text: `    Link  : https://secure-${target}-login.example.com` });
    addLine({ type: "error",   text: `[!] Bu şablon eğitim amaçlıdır. Gerçek phishing yasadışıdır!` });
  }

  else if (toolName === "E-posta Sahteciliği") {
    addLine({ type: "info", text: `[*] ${target} SPF/DKIM/DMARC kontrol ediliyor...` });
    try {
      const [spf, dmarc] = await Promise.all([
        fetch(`https://dns.google/resolve?name=${target}&type=TXT`).then(r => r.json()),
        fetch(`https://dns.google/resolve?name=_dmarc.${target}&type=TXT`).then(r => r.json()),
      ]);
      const spfRec = spf.Answer?.find((a: {data: string}) => a.data.includes("v=spf1"));
      const dmarcRec = dmarc.Answer?.[0];
      addLine({ type: spfRec   ? "success" : "error", text: spfRec   ? `[+] SPF  : ${spfRec.data.substring(0,60)}` : `[!] SPF kaydı YOK — e-posta sahteciliğine açık!` });
      addLine({ type: dmarcRec ? "success" : "error", text: dmarcRec ? `[+] DMARC: ${dmarcRec.data.substring(0,60)}` : `[!] DMARC kaydı YOK!` });
    } catch { addLine({ type: "error", text: "[!] Sorgu başarısız." }); }
  }

  else if (toolName === "QR Kod Üretici") {
    addLine({ type: "info", text: `[*] "${target}" için QR kod linki oluşturuluyor...` });
    await delay(300);
    addLine({ type: "success", text: `[+] QR Kod API linki:` });
    addLine({ type: "data",    text: `    https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(target)}&size=200x200` });
    addLine({ type: "info",    text: `[*] Bu linki tarayıcıda açarak QR kodunuzu indirebilirsiniz.` });
  }

  else if (toolName === "URL Kısaltıcı & Analiz") {
    addLine({ type: "info", text: `[*] ${target} URL analiz ediliyor...` });
    await delay(300);
    addLine({ type: "success", text: `[+] URL bilgileri:` });
    try {
      const u = new URL(target.startsWith("http") ? target : `https://${target}`);
      addLine({ type: "data", text: `    Protokol : ${u.protocol}` });
      addLine({ type: "data", text: `    Host     : ${u.hostname}` });
      addLine({ type: "data", text: `    Port     : ${u.port || "varsayılan"}` });
      addLine({ type: "data", text: `    Path     : ${u.pathname}` });
      addLine({ type: "data", text: `    Params   : ${u.search || "yok"}` });
      const suspicious = ["bit.ly","tinyurl","t.co","ow.ly","short.link"].some(s => u.hostname.includes(s));
      addLine({ type: suspicious ? "error" : "success", text: `    Kısaltıcı: ${suspicious ? "EVET — dikkatli olun!" : "Hayır"}` });
    } catch { addLine({ type: "error", text: "[!] Geçersiz URL formatı." }); }
  }

  else if (toolName === "Pretexting Şablonlar") {
    addLine({ type: "info", text: `[*] "${target}" için pretexting şablonları...` });
    await delay(300);
    const templates = [
      "IT Desteği: Şifreniz süresi dolmak üzere. Lütfen sisteme giriş yapın.",
      "İK: Maaş ayarlaması için formunuzu doldurun.",
      "Güvenlik Ekibi: Hesabınızda şüpheli giriş tespit edildi.",
      "Yönetici: Acil belge onayı gerekiyor.",
    ];
    addLine({ type: "success", text: `[+] Eğitim senaryoları:` });
    templates.forEach((t, i) => addLine({ type: "data", text: `    ${i+1}. ${t}` }));
    addLine({ type: "error", text: `[!] Sadece farkındalık eğitimi için kullanın.` });
  }

  else if (toolName === "Awareness Test") {
    addLine({ type: "info", text: `[*] "${target}" farkındalık testi başlatılıyor...` });
    await delay(500);
    const q = [
      { q: "Bilinmeyen linkler tıklanmalı mı?", a: "HAYIR" },
      { q: "Şifre e-posta ile paylaşılabilir mi?", a: "HAYIR" },
      { q: "2FA kullanmak önemli midir?", a: "EVET" },
      { q: "Halka açık WiFi'de VPN kullanılmalı mı?", a: "EVET" },
    ];
    q.forEach((item, i) => {
      addLine({ type: "data",    text: `\n    Soru ${i+1}: ${item.q}` });
      addLine({ type: "success", text: `    Cevap  : ${item.a}` });
    });
    addLine({ type: "success", text: `\n[+] Temel güvenlik farkındalığı testi tamamlandı.` });
  }

  // ─── Sistem Araçları ─────────────────────────────────────
  else if (toolName === "İşlem Yöneticisi") {
    addLine({ type: "info", text: `[*] "${target}" işlem listesinde aranıyor...` });
    await delay(400);
    const procs = [
      { pid: 1234, name: "chrome.exe",   cpu: "12.3%", mem: "245MB" },
      { pid: 5678, name: "node.exe",     cpu: "3.1%",  mem: "87MB"  },
      { pid: 9012, name: "explorer.exe", cpu: "0.8%",  mem: "42MB"  },
      { pid: 3456, name: target || "svchost.exe", cpu: "0.2%", mem: "18MB" },
    ];
    addLine({ type: "success", text: `[+] PID   İşlem              CPU    Bellek` });
    addLine({ type: "data",    text: `    ${"─".repeat(45)}` });
    procs.forEach(p => addLine({ type: "data", text: `    ${String(p.pid).padEnd(6)}${p.name.padEnd(20)}${p.cpu.padEnd(8)}${p.mem}` }));
  }

  else if (toolName === "Dosya Hash Kontrolü") {
    addLine({ type: "info", text: `[*] Hash hesaplanıyor...` });
    const [s1, s256, s512] = await Promise.all([
      sha(target, "SHA-1"), sha(target, "SHA-256"), sha(target, "SHA-512")
    ]);
    addLine({ type: "success", text: `[+] Hash sonuçları:` });
    addLine({ type: "data",    text: `    SHA-1  : ${s1}` });
    addLine({ type: "data",    text: `    SHA-256: ${s256}` });
    addLine({ type: "data",    text: `    SHA-512: ${s512.substring(0, 64)}...` });
  }

  else if (toolName === "Registry Analizi") {
    addLine({ type: "info", text: `[*] "${target}" registry taraması...` });
    await delay(500);
    const keys = [
      `HKLM\\SOFTWARE\\${target}`,
      `HKCU\\SOFTWARE\\${target}`,
      `HKLM\\SYSTEM\\CurrentControlSet\\Services\\${target}`,
    ];
    keys.forEach((k, i) => {
      const found = Math.random() > 0.5;
      addLine({ type: found ? "success" : "info", text: found ? `[+] BULUNDU: ${k}` : `[-] Yok    : ${k}` });
    });
  }

  else if (toolName === "Log Analizi") {
    addLine({ type: "info", text: `[*] "${target}" log analizi...` });
    await delay(400);
    const events = [
      { time: "2025-03-28 01:12:44", level: "WARN",  msg: `Başarısız giriş: ${target}` },
      { time: "2025-03-28 02:33:10", level: "ERROR", msg: `Bağlantı zaman aşımı` },
      { time: "2025-03-28 08:00:01", level: "INFO",  msg: `Servis başlatıldı` },
      { time: "2025-03-28 11:45:22", level: "WARN",  msg: `Yüksek CPU kullanımı: %87` },
    ];
    events.forEach(e => {
      const t = e.level === "ERROR" ? "error" : e.level === "WARN" ? "info" : "success";
      addLine({ type: t, text: `[${e.level}] ${e.time}  ${e.msg}` });
    });
    addLine({ type: "success", text: `\n[+] ${events.length} log olayı analiz edildi.` });
  }

  else if (toolName === "Servis Yöneticisi") {
    addLine({ type: "info", text: `[*] Sistem servisleri listeleniyor...` });
    await delay(400);
    const services = [
      { name: target || "nginx",     status: "ÇALIŞIYOR", port: 80  },
      { name: "sshd",               status: "ÇALIŞIYOR", port: 22  },
      { name: "mysql",              status: "ÇALIŞIYOR", port: 3306 },
      { name: "cron",               status: "ÇALIŞIYOR", port: 0   },
      { name: "ufw",                status: "ÇALIŞIYOR", port: 0   },
    ];
    addLine({ type: "success", text: `[+] Servis              Durum        Port` });
    services.forEach(s => addLine({ type: "data", text: `    ${s.name.padEnd(20)}${s.status.padEnd(14)}${s.port || "-"}` }));
  }

  else if (toolName === "Başlangıç Tarayıcı") {
    addLine({ type: "info", text: `[*] Otomatik başlangıç programları taranıyor...` });
    await delay(500);
    const items = [
      { name: "OneDrive.exe",     path: "C:\\Users\\...\\OneDrive.exe",    risk: false },
      { name: "Discord.exe",      path: "C:\\Users\\...\\Discord\\Discord.exe", risk: false },
      { name: target || "update.exe", path: `C:\\Temp\\${target || "update"}.exe`, risk: true },
      { name: "Teams.exe",        path: "C:\\Users\\...\\Teams\\Teams.exe", risk: false },
    ];
    items.forEach(i => addLine({ type: i.risk ? "error" : "success",
      text: `${i.risk ? "[!] ŞÜPHELİ" : "[+] Normal "} ${i.name.padEnd(20)} ${i.path}` }));
  }

  // ─── Eğitim ─────────────────────────────────────────────
  else if (toolName === "Güvenlik Sözlüğü") {
    const term = target.toLowerCase();
    const dict: Record<string, string> = {
      "sql injection": "SQL Injection: Kötü amaçlı SQL kodunun veritabanı sorgularına enjekte edilmesi.",
      "xss": "XSS (Cross-Site Scripting): Saldırganın zararlı betikleri web sitesine enjekte etmesi.",
      "csrf": "CSRF: Kimlik doğrulanmış kullanıcıyı istemeden zararlı işlemler yaptırmak.",
      "ddos": "DDoS: Dağıtık hizmet dışı bırakma — sistemi aşırı istekle çökertme.",
      "phishing": "Phishing: Kullanıcıları sahte site/e-posta ile kandırarak bilgi çalma.",
      "osint": "OSINT: Açık kaynaklı istihbarat — kamuya açık kaynaklardan veri toplama.",
      "pentest": "Pentest: Yetkili güvenlik testi — sisteme saldırarak açıkları bulmak.",
      "payload": "Payload: Saldırıda zararlı etkiyi gerçekleştiren kod parçası.",
      "exploit": "Exploit: Güvenlik açığından yararlanan hazır saldırı kodu/tekniği.",
      "firewall": "Firewall: Ağ trafiğini izleyen ve filtreleyen güvenlik sistemi.",
      "vpn": "VPN: Sanal özel ağ — şifreli tünel ile güvenli bağlantı.",
      "hash": "Hash: Veriyi sabit uzunlukta özete dönüştüren tek yönlü fonksiyon.",
      "brute force": "Brute Force: Tüm kombinasyonları deneyerek şifre kırma yöntemi.",
      "zero day": "Zero-Day: Yamaya sahip olmayan, yeni keşfedilmiş güvenlik açığı.",
      "backdoor": "Backdoor: Sistemde gizli bırakılan yetkisiz erişim noktası.",
      "keylogger": "Keylogger: Klavye girişlerini kaydeden zararlı yazılım.",
      "ransomware": "Ransomware: Dosyaları şifreleyip fidye talep eden zararlı yazılım.",
      "mitm": "MITM (Man-in-the-Middle): İki taraf arasındaki iletişimi gizlice izleme.",
      "arp spoofing": "ARP Spoofing: Ağdaki ARP tablolarını manipüle ederek trafiği yönlendirme.",
      "fuzzing": "Fuzzing: Rastgele/beklenmedik girdilerle sistem açıklarını tespit etme.",
    };
    const found = Object.entries(dict).find(([k]) => term.includes(k) || k.includes(term));
    if (found) {
      addLine({ type: "success", text: `[+] ${found[0].toUpperCase()}` });
      addLine({ type: "data",    text: `    ${found[1]}` });
    } else {
      addLine({ type: "error", text: `[!] "${target}" sözlükte bulunamadı.` });
      addLine({ type: "info",  text: `[*] Dene: xss, sqli, csrf, ddos, phishing, pentest, hash, brute force, zero day...` });
    }
  }

  else if (toolName === "CTF Rehberi") {
    addLine({ type: "info", text: `[*] "${target}" CTF kategorisi için rehber...` });
    await delay(300);
    const guides: Record<string, string[]> = {
      "web":      ["SQL Injection dene","Kaynak kodunu incele","Cookie/Session manipülasyonu","XSS ile cookie çal"],
      "crypto":   ["Hash türünü belirle","Caesar/Vigenere şifresi dene","Base64 decode et","RSA zayıf anahtar kontrolü"],
      "forensics":["Dosya meta verisine bak","Steganografi kontrol et","Log dosyalarını analiz et","Silinen dosyaları kurtar"],
      "pwn":      ["Buffer overflow kontrol et","ROP gadget ara","Format string açığı dene","Heap exploit dene"],
      "reverse":  ["Strings komutunu çalıştır","Ghidra/IDA ile analiz et","Dinamik analiz yap","Anti-debug kontrol et"],
    };
    const cat = term.toLowerCase();
    const guide = Object.entries(guides).find(([k]) => cat.includes(k));
    if (guide) {
      addLine({ type: "success", text: `[+] ${guide[0].toUpperCase()} Kategorisi:` });
      guide[1].forEach((s, i) => addLine({ type: "data", text: `    ${i+1}. ${s}` }));
    } else {
      addLine({ type: "success", text: `[+] CTF Kategorileri: web, crypto, forensics, pwn, reverse` });
      addLine({ type: "info",    text: `[*] Kategori adını girerek detaylı rehbere erişin.` });
    }
  }

  else if (toolName === "Cheatsheetler") {
    addLine({ type: "info", text: `[*] "${target}" cheatsheet aranıyor...` });
    await delay(300);
    const sheets: Record<string, string[]> = {
      "nmap":      ["nmap -sV -sC target","nmap -p- target","nmap -A -T4 target","nmap --script vuln target"],
      "sqlmap":    ["sqlmap -u URL --dbs","sqlmap -u URL -D db --tables","sqlmap -u URL --dump","sqlmap -u URL --forms"],
      "burp":      ["Proxy: 127.0.0.1:8080","Intercept ON/OFF: Ctrl+T","Repeater: Ctrl+R","Intruder: Ctrl+I"],
      "metasploit":["msfconsole","search exploit","use exploit/...","set RHOST ip","run"],
      "linux":     ["whoami / id","netstat -tulnp","find / -perm -4000","cat /etc/passwd","history"],
    };
    const key = Object.keys(sheets).find(k => target.toLowerCase().includes(k));
    if (key) {
      addLine({ type: "success", text: `[+] ${key.toUpperCase()} Komutları:` });
      sheets[key].forEach(c => addLine({ type: "data", text: `    $ ${c}` }));
    } else {
      addLine({ type: "success", text: `[+] Mevcut cheatsheetler: nmap, sqlmap, burp, metasploit, linux` });
    }
  }

  else if (toolName === "Sertifika Yol Haritası") {
    addLine({ type: "info", text: `[*] "${target}" sertifika bilgisi aranıyor...` });
    await delay(300);
    const certs: Record<string, { level: string; topics: string[]; link: string }> = {
      "ceh":  { level: "Orta", topics: ["Ethical Hacking","Recon","Exploitation","Social Engineering"], link: "eccouncil.org/ceh" },
      "oscp": { level: "İleri", topics: ["Pentest","Exploitation","Buffer Overflow","Privilege Escalation"], link: "offsec.com/oscp" },
      "security+": { level: "Başlangıç", topics: ["Network Security","Threats","Cryptography","Compliance"], link: "comptia.org/security-plus" },
      "ejpt": { level: "Başlangıç", topics: ["Temel Pentest","Network","Web Hacking","Host Recon"], link: "ine.com/ejpt" },
    };
    const key = Object.keys(certs).find(k => target.toLowerCase().includes(k));
    if (key) {
      const c = certs[key];
      addLine({ type: "success", text: `[+] ${key.toUpperCase()} Sertifikası:` });
      addLine({ type: "data",    text: `    Seviye: ${c.level}` });
      addLine({ type: "data",    text: `    Konular: ${c.topics.join(", ")}` });
      addLine({ type: "data",    text: `    Link: https://${c.link}` });
    } else {
      addLine({ type: "success", text: `[+] Önerilen Sertifika Yolu:` });
      addLine({ type: "data",    text: `    1. Başlangıç : CompTIA Security+ / eJPT` });
      addLine({ type: "data",    text: `    2. Orta      : CEH / PNPT` });
      addLine({ type: "data",    text: `    3. İleri     : OSCP / OSED / OSWE` });
    }
  }

  else {
    addLine({ type: "info", text: `[*] Araç: ${toolName}` });
    await delay(400);
    addLine({ type: "success", text: `[+] Hedef alındı: ${target}` });
    addLine({ type: "info", text: `[*] Bu araç yakında tam implementasyon kazanacak.` });
    addLine({ type: "data", text: `[*] Güncellemeler: discord.gg/J5VaDwqru` });
  }

  addLine({ type: "info", text: `\n[✓] İşlem tamamlandı.` });
}

// ─── Input Configs ───────────────────────────────────────
const toolInputs: Record<string, { label: string; placeholder: string; defaultValue?: string; type?: string }[]> = {
  "IP Geolocation":        [{ label: "IP Adresi",              placeholder: "Örn: 8.8.8.8",               defaultValue: "8.8.8.8" }],
  "DNS Keşif":             [{ label: "Alan Adı",               placeholder: "Örn: google.com",             defaultValue: "google.com" }],
  "WHOIS Sorgulama":       [{ label: "Domain / IP",            placeholder: "Örn: google.com",             defaultValue: "cloudflare.com" }],
  "E-posta Toplama":       [{ label: "Alan Adı",               placeholder: "Örn: hedef.com",              defaultValue: "example.com" }],
  "Subdomain Tarayıcı":    [{ label: "Alan Adı",               placeholder: "Örn: hedef.com",              defaultValue: "google.com" }],
  "OSINT Araçları":        [{ label: "Kullanıcı Adı",          placeholder: "Araştırılacak kullanıcı adı", defaultValue: "aethron" }],
  "Port Tarayıcı":         [{ label: "Hedef Host",             placeholder: "Örn: 192.168.1.1",            defaultValue: "192.168.1.1" }],
  "Servis Tespiti":        [{ label: "Hedef Host",             placeholder: "Örn: 192.168.1.1",            defaultValue: "192.168.1.100" }],
  "Ping Taraması":         [{ label: "IP / Aralık",            placeholder: "Örn: 192.168.1.1",            defaultValue: "192.168.1.1" }],
  "Traceroute":            [{ label: "Hedef",                  placeholder: "Örn: 8.8.8.8",               defaultValue: "8.8.8.8" }],
  "ARP Taraması":          [{ label: "Ağ Aralığı",             placeholder: "Örn: 192.168.1.1",            defaultValue: "192.168.1.1" }],
  "Banner Grabbing":       [{ label: "Hedef IP:Port",          placeholder: "Örn: 192.168.1.1:80",         defaultValue: "192.168.1.1:80" }],
  "CVE Tarayıcı":          [{ label: "Yazılım / Versiyon",     placeholder: "Örn: apache 2.4.50",          defaultValue: "apache 2.4.50" }],
  "SQL Injection Test":    [{ label: "Hedef URL",              placeholder: "Örn: site.com/page?id=1",     defaultValue: "hedef.com/sayfa?id=1" }],
  "XSS Tespiti":           [{ label: "Hedef URL",              placeholder: "Örn: site.com/search",        defaultValue: "hedef.com/arama" }],
  "SSL/TLS Analizi":       [{ label: "Domain",                 placeholder: "Örn: google.com",             defaultValue: "github.com" }],
  "Misconfiguration Tarayıcı": [{ label: "Hedef URL",         placeholder: "Örn: https://hedef.com",      defaultValue: "https://hedef.com" }],
  "Exploit Veritabanı":    [{ label: "Arama Terimi",           placeholder: "Örn: apache, wordpress",      defaultValue: "log4j" }],
  "Şifre Gücü Testi":      [{ label: "Şifre",                 placeholder: "Test edilecek şifre",         defaultValue: "P@ssw0rd123!", type: "password" }],
  "Hash Tanımlayıcı":      [{ label: "Hash Değeri",           placeholder: "Hash girin",                  defaultValue: "5f4dcc3b5aa765d61d8327deb882cf99" }],
  "Hash Kırıcı":           [{ label: "Hash (SHA-1/SHA-256)",  placeholder: "Kırılacak hash değeri",       defaultValue: "5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8" }],
  "Wordlist Üretici":      [{ label: "Anahtar Kelime",        placeholder: "Örn: admin, firma, isim",     defaultValue: "aethron" }],
  "Brute Force":           [{ label: "Hedef Servis",          placeholder: "Örn: 192.168.1.1:22 (SSH)",   defaultValue: "192.168.1.1:22" }],
  "Credential Dump Analiz":[{ label: "E-posta / Kullanıcı",  placeholder: "Örn: user@example.com",       defaultValue: "test@example.com" }],
  "Dizin Tarayıcı":        [{ label: "Hedef URL",             placeholder: "Örn: https://hedef.com",      defaultValue: "https://hedef.com" }],
  "HTTP Başlık Analizi":   [{ label: "Domain",                placeholder: "Örn: google.com",             defaultValue: "google.com" }],
  "CMS Tespiti":           [{ label: "Hedef URL",             placeholder: "Örn: https://hedef.com",      defaultValue: "https://hedef.com" }],
  "Web Crawler":           [{ label: "Hedef URL",             placeholder: "Örn: https://hedef.com",      defaultValue: "https://hedef.com" }],
  "Cookie Analizi":        [{ label: "Domain",                placeholder: "Örn: hedef.com",              defaultValue: "hedef.com" }],
  "API Keşif":             [{ label: "Hedef URL",             placeholder: "Örn: https://api.hedef.com",  defaultValue: "https://api.hedef.com" }],
  "WiFi Tarayıcı":         [{ label: "SSID / Filtre",         placeholder: "Tümü için boş bırakın",       defaultValue: "HomeNetwork" }],
  "WPS Tester":            [{ label: "Hedef BSSID",           placeholder: "Örn: AA:BB:CC:DD:EE:FF",      defaultValue: "AA:BB:CC:DD:EE:FF" }],
  "Handshake Yakalayıcı":  [{ label: "Hedef SSID",           placeholder: "Hedef WiFi adı",              defaultValue: "HomeNetwork_5G" }],
  "Deauth Tester":         [{ label: "Hedef BSSID",          placeholder: "Örn: AA:BB:CC:DD:EE:FF",      defaultValue: "AA:BB:CC:DD:EE:FF" }],
  "SSID Analizi":          [{ label: "SSID",                  placeholder: "WiFi ağ adı",                 defaultValue: "TP-Link_5GHz" }],
  "Sinyal Haritalama":     [{ label: "SSID",                  placeholder: "Haritası çıkarılacak ağ",    defaultValue: "HomeNetwork" }],
  "Phishing Simülatörü":   [{ label: "Hedef Marka/Domain",   placeholder: "Örn: google, paypal",         defaultValue: "google" }],
  "E-posta Sahteciliği":   [{ label: "Domain",               placeholder: "Örn: hedef.com",              defaultValue: "example.com" }],
  "QR Kod Üretici":        [{ label: "İçerik / URL",         placeholder: "QR koda kodlanacak metin",    defaultValue: "https://discord.gg/J5VaDwqru" }],
  "URL Kısaltıcı & Analiz":[{ label: "URL",                  placeholder: "Örn: https://bit.ly/abc123",  defaultValue: "https://bit.ly/3abc123" }],
  "Pretexting Şablonlar":  [{ label: "Senaryo Konusu",       placeholder: "Örn: IT, İK, Yönetim",        defaultValue: "IT Desteği" }],
  "Awareness Test":        [{ label: "Departman / Konu",     placeholder: "Örn: IT, Finans, Genel",      defaultValue: "Genel" }],
  "İşlem Yöneticisi":      [{ label: "İşlem Adı",            placeholder: "Örn: chrome, svchost",        defaultValue: "chrome" }],
  "Dosya Hash Kontrolü":   [{ label: "Metin / İçerik",       placeholder: "Hash alınacak metin",         defaultValue: "aethron_system_v2" }],
  "Registry Analizi":      [{ label: "Uygulama / Anahtar",   placeholder: "Örn: Chrome, Discord",        defaultValue: "Chrome" }],
  "Log Analizi":           [{ label: "Uygulama / Servis",    placeholder: "Örn: nginx, sshd, apache",    defaultValue: "nginx" }],
  "Servis Yöneticisi":     [{ label: "Servis Adı",           placeholder: "Örn: nginx, mysql, sshd",     defaultValue: "nginx" }],
  "Başlangıç Tarayıcı":    [{ label: "Uygulama Adı",         placeholder: "Tümü için boş bırakın",       defaultValue: "" }],
  "CTF Rehberi":           [{ label: "Kategori",             placeholder: "web, crypto, forensics, pwn, reverse", defaultValue: "web" }],
  "Güvenlik Sözlüğü":      [{ label: "Terim",                placeholder: "Örn: xss, sql injection, ddos...", defaultValue: "sql injection" }],
  "Cheatsheetler":         [{ label: "Araç Adı",             placeholder: "nmap, sqlmap, burp, metasploit, linux", defaultValue: "nmap" }],
  "Sertifika Yol Haritası":[{ label: "Sertifika / Seviye",  placeholder: "Örn: CEH, OSCP, Security+",   defaultValue: "oscp" }],
};

// ─── Component ────────────────────────────────────────────
export function ToolModal({ tool, onClose }: ToolModalProps) {
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [output, setOutput] = useState<OutputLine[]>([]);
  const [running, setRunning] = useState(false);
  const outputRef = useRef<HTMLDivElement>(null);

  const inputConfigs = tool
    ? (toolInputs[tool.name] || [{ label: "Hedef", placeholder: "Hedef girin...", defaultValue: "" }])
    : [];

  useEffect(() => {
    if (tool) {
      const configs = toolInputs[tool.name] || [{ label: "Hedef", placeholder: "Hedef girin...", defaultValue: "" }];
      const defaults: Record<string, string> = {};
      configs.forEach(c => { defaults[c.label] = c.defaultValue ?? ""; });
      setInputs(defaults);
      setOutput([]);
    }
  }, [tool?.name]);

  function addLine(line: OutputLine) {
    setOutput(prev => [...prev, line]);
    setTimeout(() => outputRef.current?.scrollTo({ top: 99999, behavior: "smooth" }), 30);
  }

  async function handleRun() {
    setRunning(true);
    setOutput([]);
    if (tool) await runTool(tool.name, inputs, addLine);
    setRunning(false);
  }

  function copyOutput() {
    navigator.clipboard.writeText(output.map(l => l.text).join("\n"));
  }

  const lineColor: Record<string, string> = {
    info:    "text-blue-400",
    success: "text-green-400",
    error:   "text-red-400",
    data:    "text-gray-300",
    cmd:     "text-primary font-bold",
  };

  return (
    <AnimatePresence>
      {tool && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] flex items-center justify-center p-4"
          onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
        >
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />

          <motion.div
            initial={{ opacity: 0, scale: 0.93, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.93, y: 20 }}
            transition={{ type: "spring", duration: 0.4 }}
            className="relative w-full max-w-2xl bg-[#0a0a0a] border border-white/10 rounded-2xl overflow-hidden shadow-[0_0_80px_rgba(220,38,38,0.15)] flex flex-col"
            style={{ maxHeight: "90vh" }}
          >
            <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent" />

            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <Terminal className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-sm text-foreground">{tool.name}</h3>
                  <p className="text-xs text-muted-foreground">{tool.category}</p>
                </div>
              </div>
              <button onClick={onClose} className="w-7 h-7 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="px-6 py-3 bg-white/2 border-b border-white/5 shrink-0">
              <p className="text-xs text-muted-foreground">{tool.desc}</p>
            </div>

            <div className="flex flex-col flex-1 overflow-hidden">
              {/* Inputs */}
              <div className="px-6 py-4 space-y-3 shrink-0 border-b border-white/5">
                {inputConfigs.map((inp) => (
                  <div key={inp.label} className="flex gap-2 items-center">
                    <label className="text-xs text-muted-foreground font-mono w-36 shrink-0">{inp.label}:</label>
                    <input
                      type={inp.type || "text"}
                      placeholder={inp.placeholder}
                      value={inputs[inp.label] || ""}
                      onChange={(e) => setInputs(prev => ({ ...prev, [inp.label]: e.target.value }))}
                      onKeyDown={(e) => e.key === "Enter" && !running && handleRun()}
                      className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50 font-mono"
                    />
                  </div>
                ))}
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={handleRun}
                    disabled={running}
                    className="flex items-center gap-2 px-5 py-2 rounded-lg bg-primary text-primary-foreground font-display font-bold text-xs uppercase tracking-wider hover:shadow-[0_0_15px_rgba(220,38,38,0.4)] disabled:opacity-60 transition-all"
                  >
                    {running ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                    {running ? "Çalışıyor..." : "Çalıştır"}
                  </button>
                  <button onClick={() => setOutput([])} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-muted-foreground hover:text-foreground transition-colors">
                    <Trash2 className="w-3.5 h-3.5" /> Temizle
                  </button>
                  {output.length > 0 && (
                    <button onClick={copyOutput} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-xs text-muted-foreground hover:text-foreground transition-colors ml-auto">
                      <Copy className="w-3.5 h-3.5" /> Kopyala
                    </button>
                  )}
                </div>
              </div>

              {/* Terminal Output */}
              <div ref={outputRef} className="flex-1 overflow-y-auto px-6 py-4 font-mono text-xs space-y-0.5 bg-black/40 min-h-[160px]">
                {output.length === 0 && !running && (
                  <div className="flex items-center gap-2 text-muted-foreground/40 text-xs h-full justify-center">
                    <ChevronRight className="w-4 h-4" />
                    <span>Değeri gir ve Enter'a bas veya Çalıştır'a tıkla</span>
                  </div>
                )}
                {output.map((line, i) => (
                  <div key={i} className={`${lineColor[line.type]} whitespace-pre-wrap leading-5`}>
                    {line.text}
                  </div>
                ))}
                {running && (
                  <div className="flex items-center gap-1.5 text-primary animate-pulse mt-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
                    <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
                    <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
