import { useState, useEffect } from "react";
import { Menu, X, ShieldAlert, LogIn, LogOut, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/auth-context";

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logout, setShowAuthModal, setAuthTab } = useAuth();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Ana Sayfa", href: "#home" },
    { name: "Araçlar", href: "#tools" },
    { name: "Discord", href: "#discord" },
    { name: "Hakkında", href: "#about" },
  ];

  function openLogin() {
    setAuthTab("login");
    setShowAuthModal(true);
    setMobileMenuOpen(false);
  }

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b",
        isScrolled
          ? "bg-background/80 backdrop-blur-md border-primary/20 py-3 shadow-[0_4px_30px_rgba(255,0,0,0.05)]"
          : "bg-transparent border-transparent py-5"
      )}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <a href="#home" className="flex items-center gap-3 group">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 border border-primary/30 group-hover:border-primary/60 transition-colors overflow-hidden">
              <ShieldAlert className="w-5 h-5 text-primary" />
            </div>
            <span className="font-display font-bold text-xl tracking-wider text-foreground group-hover:text-primary transition-colors">
              AETHRON<span className="text-primary"> </span>SYSTEM
            </span>
          </a>

          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-all duration-200 uppercase tracking-widest font-display"
              >
                {link.name}
              </a>
            ))}

            {user ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-sm font-display">
                  <User className="w-4 h-4 text-primary" />
                  <span className="text-foreground font-bold">{user.username}</span>
                </div>
                <button
                  onClick={logout}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-display font-bold uppercase tracking-wider text-muted-foreground border border-white/10 hover:border-primary/40 hover:text-primary transition-all"
                >
                  <LogOut className="w-4 h-4" />
                  Çıkış
                </button>
              </div>
            ) : (
              <button
                onClick={openLogin}
                className="flex items-center gap-2 px-5 py-2 rounded-md font-display font-bold uppercase tracking-wider text-sm bg-primary/10 text-primary border border-primary/50 hover:bg-primary hover:text-primary-foreground hover:shadow-[0_0_20px_rgba(220,38,38,0.4)] transition-all duration-300"
              >
                <LogIn className="w-4 h-4" />
                Giriş Yap
              </button>
            )}
          </nav>

          <button
            className="md:hidden text-muted-foreground hover:text-primary transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-background/95 backdrop-blur-xl border-b border-primary/20 overflow-hidden"
          >
            <div className="flex flex-col px-4 py-6 space-y-4">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-lg font-display font-semibold text-foreground hover:text-primary p-2 border-b border-white/5 uppercase tracking-wide"
                >
                  {link.name}
                </a>
              ))}
              {user ? (
                <>
                  <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 border border-white/10">
                    <User className="w-4 h-4 text-primary" />
                    <span className="text-foreground font-bold font-display">{user.username}</span>
                  </div>
                  <button
                    onClick={() => { logout(); setMobileMenuOpen(false); }}
                    className="px-6 py-3 rounded-md font-display font-bold text-center uppercase tracking-wider border border-white/10 text-muted-foreground hover:text-primary flex items-center justify-center gap-2"
                  >
                    <LogOut className="w-4 h-4" /> Çıkış Yap
                  </button>
                </>
              ) : (
                <button
                  onClick={openLogin}
                  className="mt-4 px-6 py-3 rounded-md font-display font-bold text-center uppercase tracking-wider bg-primary text-primary-foreground shadow-[0_0_15px_rgba(220,38,38,0.3)] flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4" /> Giriş Yap / Kayıt Ol
                </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
