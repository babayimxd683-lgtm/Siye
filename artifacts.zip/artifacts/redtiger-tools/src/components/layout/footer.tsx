import { Github, Shield, AlertTriangle, MessageCircle } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-background border-t border-white/5 pt-16 pb-8 relative overflow-hidden">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-3xl h-32 bg-primary/5 blur-[100px] pointer-events-none rounded-t-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6 text-primary" />
              <span className="font-display font-bold text-xl tracking-wider">
                AETHRON<span className="text-primary"> </span>SYSTEM
              </span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
              Eğitim amaçlı tasarlanmış, güvenli ve yüksek performanslı siber güvenlik araç seti. 9 kategori, 54 araç.
              <span className="block mt-1 text-primary/70 font-semibold">by aethron</span>
            </p>
            <div className="flex space-x-3 pt-2">
              <a
                href="https://github.com/elmahdy1986/RedTiger-Tools"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-white hover:shadow-[0_0_15px_rgba(220,38,38,0.4)] transition-all duration-300"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="https://discord.gg/J5VaDwqru"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:bg-[#5865F2] hover:text-white hover:shadow-[0_0_15px_rgba(88,101,242,0.4)] transition-all duration-300"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-display font-bold text-lg mb-4 text-foreground uppercase tracking-wide">Hızlı Bağlantılar</h3>
            <ul className="space-y-2">
              {[
                { label: "Ana Sayfa", href: "#home" },
                { label: "Araçlar", href: "#tools" },
                { label: "Discord", href: "#discord" },
                { label: "Hakkında", href: "#about" },
              ].map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    className="text-muted-foreground hover:text-primary text-sm transition-colors flex items-center gap-2 before:content-[''] before:w-1 before:h-1 before:bg-primary before:rounded-full before:opacity-0 hover:before:opacity-100"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-5 relative overflow-hidden group">
              <div className="absolute top-0 left-0 w-1 h-full bg-destructive group-hover:shadow-[0_0_10px_rgba(220,38,38,0.8)] transition-all" />
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-display font-bold text-destructive mb-2 uppercase text-sm">Yasal Uyarı</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Aethron System yalnızca eğitim amaçlı tasarlanmıştır. Bu araçları sorumlu bir şekilde ve yerel yasalara uygun olarak kullanın. Yetkisiz kullanım yasal sonuçlar doğurabilir.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Aethron System. Tüm hakları saklıdır.
          </p>
          <div className="flex items-center gap-4">
            <a
              href="https://discord.gg/J5VaDwqru"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 text-xs text-[#5865F2] hover:text-[#4752c4] transition-colors font-medium"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              discord.gg/J5VaDwqru
            </a>
            <span className="text-white/10">|</span>
            <p className="text-xs text-muted-foreground">
              Made by <span className="text-primary font-bold">aethron</span>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
