import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Hero } from "@/components/sections/hero";
import { Tools } from "@/components/sections/tools";
import { Requirements } from "@/components/sections/requirements";
import { About } from "@/components/sections/about";
import { Discord } from "@/components/sections/discord";

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Tools />
        <Discord />
        <Requirements />
        <About />
      </main>
      <Footer />
    </div>
  );
}
